package com.example.gunsmod;

import net.minecraft.network.chat.Component;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.Container;
import net.minecraft.world.SimpleContainer;
import net.minecraft.world.entity.player.Inventory;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.inventory.AbstractContainerMenu;
import net.minecraft.world.inventory.ContainerLevelAccess;
import net.minecraft.world.inventory.Slot;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;

public class GunCustomizerMenu extends AbstractContainerMenu {
    private final Container gunSlot = new SimpleContainer(1);
    private final ContainerLevelAccess access;

    public GunCustomizerMenu(int id, Inventory inv, ContainerLevelAccess access) {
        super(GunsMod.CUSTOMIZER_MENU.get(), id);
        this.access = access;
        this.addSlot(new Slot(gunSlot, 0, 72, 0) {
            @Override
            public boolean mayPlace(ItemStack stack) {
                return stack.getItem() instanceof GunItem;
            }

            @Override
            public int getMaxStackSize() {
                return 1;
            }
        });
        for (int r = 0; r < 3; r++) {
            for (int c = 0; c < 9; c++) {
                this.addSlot(new Slot(inv, c + r * 9 + 9, c * 18, 26 + r * 18));
            }
        }
        for (int c = 0; c < 9; c++) {
            this.addSlot(new Slot(inv, c, c * 18, 84));
        }
    }

    @Override
    public ItemStack quickMoveStack(Player player, int index) {
        Slot slot = this.slots.get(index);
        if (!slot.hasItem()) return ItemStack.EMPTY;
        ItemStack stack = slot.getItem();
        ItemStack copy = stack.copy();
        if (index == 0) {
            if (!this.moveItemStackTo(stack, 1, 37, true)) return ItemStack.EMPTY;
        } else {
            if (!(stack.getItem() instanceof GunItem) || !this.moveItemStackTo(stack, 0, 1, false)) return ItemStack.EMPTY;
        }
        if (stack.isEmpty()) {
            slot.setByPlayer(ItemStack.EMPTY);
        } else {
            slot.setChanged();
        }
        return copy;
    }

    @Override
    public boolean stillValid(Player player) {
        return stillValid(access, player, GunsMod.CUSTOMIZER.get());
    }

    @Override
    public void removed(Player player) {
        super.removed(player);
        this.access.execute((level, pos) -> this.clearContainer(player, this.gunSlot));
    }

    private boolean pay(Player p, Item a, int na, Item b, int nb) {
        if (p.getAbilities().instabuild) return true;
        if (WorkbenchRecipes.count(p, a) < na || WorkbenchRecipes.count(p, b) < nb) return false;
        WorkbenchRecipes.consume(p, a, na);
        WorkbenchRecipes.consume(p, b, nb);
        return true;
    }

    public static final String[] SCOPE_NAMES = {"None", "Red Dot Sight", "4x Scope", "Holographic Sight", "ACOG 3x", "8x Long Range", "Thermal Scope"};
    public static final String[] SCOPE_COST = {"Free", "2 iron + 1 redstone", "4 iron + 1 diamond", "3 iron + 2 redstone", "4 iron + 1 redstone", "6 iron + 2 diamond", "6 iron + 3 diamond"};
    public static final String[] SCOPE_INFO = {"Iron sights.", "Fast aiming, small red reticle.", "Magnified optic with a full scope view.",
            "Wide holographic ring reticle, light zoom.", "Medium zoom with a chevron reticle.", "Very high zoom, mil-dot reticle. Slow to scan.", "Green thermal view with a fine reticle."};
    public static final String[] MUZZLE_NAMES = {"None", "Suppressor", "Compensator", "Flash Hider", "Muzzle Brake", "Bayonet"};
    public static final String[] MUZZLE_COST = {"Free", "4 iron + 1 diamond", "3 iron + 1 redstone", "2 iron + 1 redstone", "3 iron + 1 redstone", "3 iron"};
    public static final String[] MUZZLE_INFO = {"Bare barrel.", "Near-silent shots, no flash. Slightly less range and damage.",
            "Vents gas upward: much less muzzle climb, tighter spread.", "Hides the muzzle flash. A little less recoil.",
            "Side ports cut recoil a lot, bigger blast.", "A blade on the muzzle. Looks mean."};
    public static final String[] UNDER_NAMES = {"None", "Vertical Grip", "Angled Grip", "Laser Module", "Bipod"};
    public static final String[] UNDER_COST = {"Free", "3 iron", "3 iron + 1 redstone", "2 iron + 2 redstone", "4 iron"};
    public static final String[] UNDER_INFO = {"Nothing under the barrel.", "Less recoil and a bit steadier.", "Faster to handle, slightly wider spread.",
            "Tight spread when firing from the hip.", "Big recoil reduction and better accuracy."};
    public static final String[] AMMO_NAMES = {"Full Metal Jacket", "Hollow Point", "Armor Piercing", "Incendiary"};
    public static final String[] AMMO_COST = {"Free", "3 iron + 2 gunpowder", "4 iron + 1 diamond", "2 iron + 3 gunpowder"};
    public static final String[] AMMO_INFO = {"Standard rounds.", "+20% damage, shorter range.", "+10% damage and +10% range.", "Sets targets on fire, -10% damage."};

    private boolean payFor(Player p, int cat, int i) {
        if (i == 0 || p.getAbilities().instabuild) return true;
        Item a; int na; Item b; int nb;
        switch (cat) {
            case 0 -> { // optic
                switch (i) {
                    case 1 -> { a = Items.IRON_INGOT; na = 2; b = Items.REDSTONE; nb = 1; }
                    case 2 -> { a = Items.IRON_INGOT; na = 4; b = Items.DIAMOND; nb = 1; }
                    case 3 -> { a = Items.IRON_INGOT; na = 3; b = Items.REDSTONE; nb = 2; }
                    case 4 -> { a = Items.IRON_INGOT; na = 4; b = Items.REDSTONE; nb = 1; }
                    case 5 -> { a = Items.IRON_INGOT; na = 6; b = Items.DIAMOND; nb = 2; }
                    default -> { a = Items.IRON_INGOT; na = 6; b = Items.DIAMOND; nb = 3; }
                }
            }
            case 1 -> { // muzzle
                switch (i) {
                    case 1 -> { a = Items.IRON_INGOT; na = 4; b = Items.DIAMOND; nb = 1; }
                    case 2 -> { a = Items.IRON_INGOT; na = 3; b = Items.REDSTONE; nb = 1; }
                    case 3 -> { a = Items.IRON_INGOT; na = 2; b = Items.REDSTONE; nb = 1; }
                    case 4 -> { a = Items.IRON_INGOT; na = 3; b = Items.REDSTONE; nb = 1; }
                    default -> { a = Items.IRON_INGOT; na = 3; b = Items.IRON_INGOT; nb = 0; }
                }
            }
            case 2 -> { // underbarrel
                switch (i) {
                    case 1 -> { a = Items.IRON_INGOT; na = 3; b = Items.IRON_INGOT; nb = 0; }
                    case 2 -> { a = Items.IRON_INGOT; na = 3; b = Items.REDSTONE; nb = 1; }
                    case 3 -> { a = Items.IRON_INGOT; na = 2; b = Items.REDSTONE; nb = 2; }
                    default -> { a = Items.IRON_INGOT; na = 4; b = Items.IRON_INGOT; nb = 0; }
                }
            }
            default -> { // ammo type
                switch (i) {
                    case 1 -> { a = Items.IRON_INGOT; na = 3; b = Items.GUNPOWDER; nb = 2; }
                    case 2 -> { a = Items.IRON_INGOT; na = 4; b = Items.DIAMOND; nb = 1; }
                    default -> { a = Items.IRON_INGOT; na = 2; b = Items.GUNPOWDER; nb = 3; }
                }
            }
        }
        return pay(p, a, na, b, nb);
    }

    /** Buttons: 100+ skin, 10..16 optic, 20..25 muzzle, 30..34 underbarrel, 40..43 ammo type. */
    @Override
    public boolean clickMenuButton(Player player, int id) {
        ItemStack st = gunSlot.getItem(0);
        if (!(st.getItem() instanceof GunItem g)) return false;
        int paint = GunItem.getPaint(st);
        int scope = GunItem.getScope(st);
        int muzzle = GunItem.getMuzzle(st);
        int under = GunItem.getUnder(st);
        int ammoT = GunItem.getAmmoType(st);
        if (id >= 100 && id < 100 + Paints.COUNT) {
            paint = id - 100;
        } else if (id >= 10 && id <= 16) {
            int n = id - 10;
            if (g.type.scoped) { msg(player, "This weapon already has a built-in scope"); return false; }
            if (n != scope) { if (!payFor(player, 0, n)) { msg(player, "Not enough materials"); return false; } scope = n; }
        } else if (id >= 20 && id <= 25) {
            int n = id - 20;
            if (!GunItem.supportsMuzzle(g.type)) { msg(player, "This weapon cannot take a muzzle device"); return false; }
            if (n != muzzle) { if (!payFor(player, 1, n)) { msg(player, "Not enough materials"); return false; } muzzle = n; }
        } else if (id >= 30 && id <= 34) {
            int n = id - 30;
            if (!GunItem.supportsUnder(g.type)) { msg(player, "This weapon cannot take an underbarrel attachment"); return false; }
            if (n != under) { if (!payFor(player, 2, n)) { msg(player, "Not enough materials"); return false; } under = n; }
        } else if (id >= 40 && id <= 43) {
            int n = id - 40;
            if (n != ammoT) { if (!payFor(player, 3, n)) { msg(player, "Not enough materials"); return false; } ammoT = n; }
        } else {
            return false;
        }
        GunItem.setCosmetics(st, paint, scope, muzzle, under, ammoT);
        gunSlot.setChanged();
        player.level().playSound(null, player.getX(), player.getY(), player.getZ(),
                SoundEvents.ANVIL_USE, SoundSource.BLOCKS, 0.4f, 1.8f);
        return true;
    }

    private static void msg(Player p, String s) {
        p.displayClientMessage(Component.literal(s), true);
    }
}
