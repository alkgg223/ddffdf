package com.example.gunsmod;

import net.minecraft.network.RegistryFriendlyByteBuf;
import net.minecraft.network.codec.ByteBufCodecs;
import net.minecraft.network.codec.StreamCodec;
import net.minecraft.network.protocol.common.custom.CustomPacketPayload;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.item.ItemStack;

/** Server -> clients: someone killed someone with a weapon. */
public record KillFeedPayload(String killer, int killerColor, ItemStack weapon, String victim, int victimColor)
        implements CustomPacketPayload {
    public static final Type<KillFeedPayload> TYPE =
            new Type<>(ResourceLocation.fromNamespaceAndPath(GunsMod.MODID, "kill_feed"));
    public static final StreamCodec<RegistryFriendlyByteBuf, KillFeedPayload> CODEC = StreamCodec.composite(
            ByteBufCodecs.STRING_UTF8, KillFeedPayload::killer,
            ByteBufCodecs.INT, KillFeedPayload::killerColor,
            ItemStack.OPTIONAL_STREAM_CODEC, KillFeedPayload::weapon,
            ByteBufCodecs.STRING_UTF8, KillFeedPayload::victim,
            ByteBufCodecs.INT, KillFeedPayload::victimColor,
            KillFeedPayload::new);

    @Override
    public Type<? extends CustomPacketPayload> type() {
        return TYPE;
    }
}
