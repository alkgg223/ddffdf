package com.example.gunsmod;

import io.netty.buffer.ByteBuf;
import net.minecraft.network.codec.StreamCodec;
import net.minecraft.network.protocol.common.custom.CustomPacketPayload;
import net.minecraft.resources.ResourceLocation;

public record ReloadPayload() implements CustomPacketPayload {
    public static final Type<ReloadPayload> TYPE =
            new Type<>(ResourceLocation.fromNamespaceAndPath(GunsMod.MODID, "reload"));
    public static final StreamCodec<ByteBuf, ReloadPayload> CODEC = StreamCodec.unit(new ReloadPayload());

    @Override
    public Type<? extends CustomPacketPayload> type() {
        return TYPE;
    }
}
