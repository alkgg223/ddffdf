package com.example.gunsmod;

import java.util.Map;
import java.util.Set;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.neoforge.event.entity.living.LivingDeathEvent;
import net.neoforged.neoforge.network.PacketDistributor;

/** Tracks which players fight on the red team of a running match, and drives the kill feed. */
@EventBusSubscriber(modid = GunsMod.MODID)
public final class ArenaManager {
    private static final Set<UUID> RED = ConcurrentHashMap.newKeySet();
    /** player -> arena table they are playing in */
    private static final Map<UUID, ArenaTableBlockEntity> PLAYING = new ConcurrentHashMap<>();

    private ArenaManager() {}

    public static boolean isRed(UUID id) {
        return RED.contains(id);
    }

    public static void join(UUID id, ArenaTableBlockEntity table) {
        RED.add(id);
        PLAYING.put(id, table);
    }

    public static void leave(UUID id) {
        RED.remove(id);
        PLAYING.remove(id);
    }

    static final int BLUE = 0x4DA3FF;
    static final int RED_C = 0xFF4D4D;

    private static boolean isBotOrPlayer(Entity e) {
        return e instanceof Player || e instanceof GunBotEntity;
    }

    private static int colorOf(Entity e) {
        if (e instanceof GunBotEntity b) return b.isAlly() ? BLUE : RED_C;
        if (e instanceof Player p) return isRed(p.getUUID()) ? RED_C : BLUE;
        return 0xFFFFFF;
    }

    @SubscribeEvent
    public static void onDeath(LivingDeathEvent e) {
        LivingEntity victim = e.getEntity();
        if (victim.level().isClientSide || !(victim.level() instanceof ServerLevel sl)) return;
        DamageSource src = e.getSource();
        Entity killer = src.getEntity();

        // arena: a player fighting in a match "respawns" instead of dying
        if (victim instanceof ServerPlayer sp && PLAYING.containsKey(sp.getUUID())) {
            ArenaTableBlockEntity t = PLAYING.get(sp.getUUID());
            e.setCanceled(true);
            sp.setHealth(sp.getMaxHealth());
            sp.getFoodData().setFoodLevel(20);
            t.onPlayerKilled(sp, killer);
            feed(sl, killer, victim, src);
            return;
        }
        if (isBotOrPlayer(victim)) feed(sl, killer, victim, src);
        if (victim instanceof GunBotEntity b) b.onKilledBy(killer);
    }

    private static void feed(ServerLevel sl, Entity killer, LivingEntity victim, DamageSource src) {
        if (killer == null || !isBotOrPlayer(killer) || !isBotOrPlayer(victim)) return;
        ItemStack weapon = killer instanceof LivingEntity le ? le.getMainHandItem().copyWithCount(1) : ItemStack.EMPTY;
        if (!(weapon.getItem() instanceof GunItem)) weapon = ItemStack.EMPTY;
        PacketDistributor.sendToAllPlayers(new KillFeedPayload(killer.getName().getString(), colorOf(killer), weapon,
                victim.getName().getString(), colorOf(victim)));
    }

    public static void tellAll(ServerLevel sl, Component c) {
        for (ServerPlayer p : sl.players()) p.sendSystemMessage(c);
    }
}
