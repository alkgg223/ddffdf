package com.example.gunsmod;

import net.minecraft.core.HolderLookup;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.util.RandomSource;
import net.minecraft.world.item.ItemStack;

/** Builds a random bot loadout: primary + sidearm, with random optic / muzzle / grip / ammo / skin, maybe grenades. */
public final class RandomLoadout {
    private static final GunType[] MAINS = {GunType.SMG, GunType.RIFLE, GunType.M4, GunType.SHOTGUN, GunType.SNIPER, GunType.LMG};
    private static final GunType[] SIDES = {GunType.PISTOL, GunType.DEAGLE};

    private RandomLoadout() {}

    public static ItemStack gun(GunType t, RandomSource r) {
        ItemStack st = new ItemStack(GunsMod.gunItem(t));
        int scope = 0;
        if (!t.scoped && r.nextInt(100) < 55) {
            boolean small = t == GunType.PISTOL || t == GunType.DEAGLE;
            scope = small ? (r.nextBoolean() ? 1 : 3) : 1 + r.nextInt(6);
        }
        int muzzle = GunItem.supportsMuzzle(t) && r.nextInt(100) < 55 ? 1 + r.nextInt(5) : 0;
        int under = GunItem.supportsUnder(t) && r.nextInt(100) < 45 ? 1 + r.nextInt(4) : 0;
        int ammoT = r.nextInt(100) < 25 ? 1 + r.nextInt(3) : 0;
        int skin = r.nextInt(Paints.COUNT);
        GunItem.setCosmetics(st, skin, scope, muzzle, under, ammoT);
        return st;
    }

    public static CompoundTag make(RandomSource r, boolean ally, HolderLookup.Provider reg) {
        GunType main = MAINS[r.nextInt(MAINS.length)];
        GunType side = SIDES[r.nextInt(SIDES.length)];
        CompoundTag t = new CompoundTag();
        t.putBoolean("Ally", ally);
        t.put("W0", gun(main, r).save(reg));
        t.put("W1", gun(side, r).save(reg));
        t.putInt("A0", main.magSize);
        t.putInt("A1", side.magSize);
        t.putInt("Active", 0);
        t.putBoolean("Grenade", r.nextInt(100) < 60);
        return t;
    }
}
