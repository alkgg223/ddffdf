package com.example.gunsmod;

import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.math.Axis;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.Font;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.player.LocalPlayer;
import net.minecraft.util.Mth;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.item.ItemStack;
import net.neoforged.api.distmarker.Dist;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.neoforge.client.event.ClientTickEvent;
import net.neoforged.neoforge.client.event.ComputeFovModifierEvent;
import net.neoforged.neoforge.client.event.RenderGuiEvent;
import net.neoforged.neoforge.client.event.RenderGuiLayerEvent;
import net.neoforged.neoforge.client.event.RenderHandEvent;
import net.neoforged.neoforge.client.gui.VanillaGuiLayers;
import net.neoforged.neoforge.network.PacketDistributor;

@EventBusSubscriber(modid = GunsMod.MODID, value = Dist.CLIENT)
public class ClientGameEvents {
    public static boolean aiming = false;

    private static float aimProg, aimProgO;
    private static float sprintProg, sprintProgO;
    private static float recoilAnim, recoilAnimO;
    private static GunItem lastGun = null;
    private static int lastSlot = -1;
    private static int lastAmmo = -1;

    // hit feedback ("124 dmg / 19 hits", floating numbers, hit marker)
    private static float hitDmg;
    private static int hitCount;
    private static int hitTimer;
    private static int markerTimer;
    private static boolean markerHead;
    private static final List<float[]> FLOATERS = new ArrayList<>(); // dmg, head, age, ox, oy

    private static final List<Object[]> FEED = new ArrayList<>(); // KillFeedPayload, age

    public static void onKillFeed(KillFeedPayload p) {
        FEED.add(new Object[]{p, 0});
        while (FEED.size() > 6) FEED.remove(0);
    }

    private static void drawFeed(GuiGraphics gg, Font font, int w) {
        int y = 6;
        for (Object[] e : FEED) {
            KillFeedPayload p = (KillFeedPayload) e[0];
            int a = (Integer) e[1];
            int w1 = font.width(p.killer()), w2 = font.width(p.victim());
            boolean gun = !p.weapon().isEmpty();
            int mid = gun ? 26 : 12;
            int rowW = w1 + w2 + mid + 10;
            int x0 = w - 8 - rowW;
            gg.fill(x0, y, x0 + rowW, y + 16, 0x99000000);
            gg.fill(x0, y, x0 + 2, y + 16, 0xFF000000 | p.killerColor());
            gg.drawString(font, p.killer(), x0 + 5, y + 4, 0xFF000000 | p.killerColor(), true);
            if (gun) {
                PoseStack ps = gg.pose();
                ps.pushPose();
                ps.translate(x0 + 5 + w1 + 4, y - 3, 0);
                ps.scale(1.25f, 1.25f, 1f);
                gg.renderItem(p.weapon(), 0, 0);
                ps.popPose();
            } else {
                gg.drawString(font, "✖", x0 + 5 + w1 + 3, y + 4, 0xFFDDDDDD, false);
            }
            gg.drawString(font, p.victim(), x0 + 5 + w1 + mid, y + 4, 0xFF000000 | p.victimColor(), true);
            y += 18;
        }
    }

    public static void onHit(float dmg, boolean head) {
        if (hitTimer <= 0) {
            hitDmg = 0;
            hitCount = 0;
        }
        hitDmg += dmg;
        hitCount++;
        hitTimer = 60;
        markerTimer = 6;
        markerHead = head;
        FLOATERS.add(new float[]{dmg, head ? 1f : 0f, 0f, (float) (Math.random() - 0.5) * 18f, (float) (Math.random() - 0.5) * 8f});
        if (FLOATERS.size() > 12) FLOATERS.remove(0);
    }

    private static boolean scopeOverlay(ItemStack st, GunItem g) {
        return g.type.scoped || GunItem.fullLens(GunItem.getScope(st));
    }

    @SubscribeEvent
    public static void onTick(ClientTickEvent.Post e) {
        LocalPlayer p = Minecraft.getInstance().player;
        if (p == null) return;
        if (hitTimer > 0) hitTimer--;
        if (markerTimer > 0) markerTimer--;
        for (int i = FEED.size() - 1; i >= 0; i--) {
            Object[] f = FEED.get(i);
            f[1] = (Integer) f[1] + 1;
            if ((Integer) f[1] > 140) FEED.remove(i);
        }
        for (int i = FLOATERS.size() - 1; i >= 0; i--) {
            float[] f = FLOATERS.get(i);
            f[2] += 1f;
            if (f[2] > 26f) FLOATERS.remove(i);
        }
        boolean holding = p.getMainHandItem().getItem() instanceof GunItem;
        while (ClientModEvents.RELOAD.consumeClick()) {
            if (holding) PacketDistributor.sendToServer(new ReloadPayload());
        }
        while (ClientModEvents.AIM.consumeClick()) {
            if (holding) {
                aiming = !aiming;
                PacketDistributor.sendToServer(new AimPayload(aiming));
            }
        }
        if (!holding && aiming) {
            aiming = false;
            PacketDistributor.sendToServer(new AimPayload(false));
        }

        aimProgO = aimProg;
        aimProg += ((aiming ? 1f : 0f) - aimProg) * 0.35f;
        boolean sprint = holding && p.isSprinting() && !aiming;
        sprintProgO = sprintProg;
        sprintProg += ((sprint ? 1f : 0f) - sprintProg) * 0.3f;
        recoilAnimO = recoilAnim;
        recoilAnim *= 0.6f;

        // Detect a shot (ammo went down) -> recoil animation + camera kick
        if (holding) {
            ItemStack st = p.getMainHandItem();
            GunItem g = (GunItem) st.getItem();
            int ammo = GunItem.getAmmo(st, g.type);
            int slot = p.getInventory().selected;
            if (slot != lastSlot || g != lastGun) {
                lastSlot = slot;
                lastGun = g;
                lastAmmo = ammo;
            } else {
                if (ammo < lastAmmo) {
                    recoilAnim = 1.0f;
                    float k = g.type.recoil * (aiming ? 0.6f : 1.0f) * GunItem.recoilMult(GunItem.mods(st));
                    p.setXRot(p.getXRot() - k);
                    p.setYRot(p.getYRot() + (float) ((Math.random() - 0.5) * k * 0.7));
                }
                lastAmmo = ammo;
            }
        } else {
            lastGun = null;
        }
    }

    @SubscribeEvent
    public static void onFov(ComputeFovModifierEvent e) {
        ItemStack held = e.getPlayer().getMainHandItem();
        if (aiming && held.getItem() instanceof GunItem g) {
            float z = g.type.zoom;
            int sc = g.type.scoped ? 0 : GunItem.getScope(held);
            if (sc > 0) z *= GunItem.scopeZoom(sc);
            e.setNewFovModifier(e.getNewFovModifier() * z);
        }
    }

    /** First-person gun animation: aim, sprint pose, recoil. */
    @SubscribeEvent
    public static void onRenderHand(RenderHandEvent e) {
        if (e.getHand() != InteractionHand.MAIN_HAND) return;
        if (!(e.getItemStack().getItem() instanceof GunItem g)) return;
        LocalPlayer p = Minecraft.getInstance().player;
        if (p == null) return;
        float pt = e.getPartialTick();
        float ap = Mth.lerp(pt, aimProgO, aimProg);
        if (scopeOverlay(e.getItemStack(), g) && ap > 0.9f) {
            e.setCanceled(true);
            return;
        }
        float sp = Mth.lerp(pt, sprintProgO, sprintProg);
        float ra = Mth.lerp(pt, recoilAnimO, recoilAnim);
        PoseStack ps = e.getPoseStack();
        ps.translate(-0.40f * ap, 0.12f * ap, 0f);
        ps.translate(0.56f, -0.52f, -0.72f);
        float bob = (float) Math.sin((p.tickCount + pt) * 0.7f) * 2.0f * sp;
        ps.mulPose(Axis.XP.rotationDegrees(-28f * sp + 7f * ra + bob));
        ps.mulPose(Axis.YP.rotationDegrees(28f * sp));
        ps.translate(0f, -0.18f * sp, 0.12f * ra);
        ps.translate(-0.56f, 0.52f, 0.72f);
    }

    // ------------------------------------------------------------------ drawing helpers
    private static void ring(GuiGraphics gg, int cx, int cy, int ro, int ri, int color) {
        for (int dy = -ro; dy <= ro; dy++) {
            int xo = (int) Math.sqrt((double) ro * ro - (double) dy * dy);
            if (Math.abs(dy) < ri) {
                int xi = (int) Math.sqrt((double) ri * ri - (double) dy * dy);
                gg.fill(cx - xo, cy + dy, cx - xi, cy + dy + 1, color);
                gg.fill(cx + xi, cy + dy, cx + xo, cy + dy + 1, color);
            } else {
                gg.fill(cx - xo, cy + dy, cx + xo, cy + dy + 1, color);
            }
        }
    }

    private static void disc(GuiGraphics gg, int cx, int cy, int r, int color) {
        ring(gg, cx, cy, r, 0, color);
    }

    /** Scope view + custom crosshair. Replaces the vanilla crosshair while a gun is held. */
    @SubscribeEvent
    public static void onGuiLayer(RenderGuiLayerEvent.Pre e) {
        if (!e.getName().equals(VanillaGuiLayers.CROSSHAIR)) return;
        Minecraft mc = Minecraft.getInstance();
        LocalPlayer p = mc.player;
        if (p == null || !(p.getMainHandItem().getItem() instanceof GunItem g)) return;
        ItemStack st = p.getMainHandItem();
        e.setCanceled(true);
        GuiGraphics gg = e.getGuiGraphics();
        int w = gg.guiWidth();
        int h = gg.guiHeight();
        int cx = w / 2;
        int cy = h / 2;

        int opt = g.type.scoped ? 0 : GunItem.getScope(st);
        if (scopeOverlay(st, g) && aimProg >= 0.9f) {
            drawScope(gg, w, h, cx, cy, opt);
        } else if (opt > 0 && aimProg >= 0.9f) {
            if (opt == 1) { // red dot: ring + dot
                disc(gg, cx, cy, 4, 0x28FF2020);
                ring(gg, cx, cy, 12, 11, 0xB0FF3030);
                gg.fill(cx - 1, cy - 1, cx + 1, cy + 1, 0xFFFF5050);
            } else if (opt == 3) { // holographic: ring, dot and four ticks
                ring(gg, cx, cy, 15, 14, 0xC0FF4040);
                gg.fill(cx - 1, cy - 1, cx + 1, cy + 1, 0xFFFF6060);
                gg.fill(cx - 22, cy, cx - 16, cy + 1, 0xC0FF4040);
                gg.fill(cx + 16, cy, cx + 22, cy + 1, 0xC0FF4040);
                gg.fill(cx, cy + 16, cx + 1, cy + 22, 0xC0FF4040);
                gg.fill(cx, cy - 22, cx + 1, cy - 16, 0xC0FF4040);
            } else { // ACOG: chevron over a lens-coloured ring
                ring(gg, cx, cy, 46, 44, 0x90000000);
                gg.fill(cx - 46, cy, cx + 46, cy + 1, 0x60000000);
                gg.fill(cx, cy - 46, cx + 1, cy + 46, 0x60000000);
                for (int i = 0; i < 9; i++) {
                    gg.fill(cx - i - 1, cy + 1 + i, cx - i, cy + 2 + i, 0xFFFF3030);
                    gg.fill(cx + i, cy + 1 + i, cx + i + 1, cy + 2 + i, 0xFFFF3030);
                }
                gg.fill(cx - 1, cy - 1, cx + 1, cy + 1, 0xFFFF3030);
            }
        } else {
            float spread = g.type.spread * (aiming ? 0.3f : 1f);
            int gap = 3 + Math.round(spread * 1.1f + recoilAnim * 5f);
            int len = aiming ? 3 : 4;
            int c = 0xE6FFFFFF;
            int s = 0x90000000;
            gg.fill(cx - gap - len - 1, cy - 1, cx - gap + 1, cy + 2, s);
            gg.fill(cx + gap - 1, cy - 1, cx + gap + len + 1, cy + 2, s);
            gg.fill(cx - 1, cy - gap - len - 1, cx + 2, cy - gap + 1, s);
            gg.fill(cx - 1, cy + gap - 1, cx + 2, cy + gap + len + 1, s);
            gg.fill(cx - gap - len, cy, cx - gap, cy + 1, c);
            gg.fill(cx + gap, cy, cx + gap + len, cy + 1, c);
            gg.fill(cx, cy - gap - len, cx + 1, cy - gap, c);
            gg.fill(cx, cy + gap, cx + 1, cy + gap + len, c);
            gg.fill(cx, cy, cx + 1, cy + 1, 0xFFFFD060);
        }
    }

    /** Sniper-style scope: lens vignette, rim, duplex reticle with mil dots. */
    private static void drawScope(GuiGraphics gg, int w, int h, int cx, int cy, int builtIn) {
        int r = (int) (h * 0.44f);
        // black outside the lens
        for (int y = 0; y < h; y++) {
            int dy = y - cy;
            if (Math.abs(dy) >= r) {
                gg.fill(0, y, w, y + 1, 0xFF000000);
            } else {
                int hw = (int) Math.sqrt((double) r * r - (double) dy * dy);
                gg.fill(0, y, cx - hw, y + 1, 0xFF000000);
                gg.fill(cx + hw, y, w, y + 1, 0xFF000000);
            }
        }
        // glass vignette (darker toward the rim)
        for (int k = 0; k < 10; k++) {
            int ro = r - k * Math.max(1, r / 60);
            int a = (int) (0x80 * (10 - k) / 10f);
            ring(gg, cx, cy, ro, ro - Math.max(1, r / 60), a << 24);
        }
        // metal rim
        ring(gg, cx, cy, r + 3, r, 0xFF0B0B0D);
        ring(gg, cx, cy, r, r - 2, 0xFF2B2E34);
        ring(gg, cx, cy, r - 2, r - 3, 0x60FFFFFF);
        if (builtIn == 6) { // thermal: green-white image tint and green reticle
            disc(gg, cx, cy, r - 3, 0x3C40FF90);
            ring(gg, cx, cy, r - 3, r / 2, 0x1800FF60);
        }
        // reticle
        int thin = builtIn == 6 ? 0xD020FF80 : 0xD0000000;
        gg.fill(cx - r + 6, cy, cx + r - 6, cy + 1, thin);
        gg.fill(cx, cy - r + 6, cx + 1, cy + r - 6, thin);
        int inner = (int) (r * 0.30f);
        int outer = (int) (r * 0.93f);
        int th = builtIn == 6 ? 0xFF20FF80 : 0xFF000000;
        gg.fill(cx - outer, cy - 1, cx - inner, cy + 2, th);
        gg.fill(cx + inner, cy - 1, cx + outer, cy + 2, th);
        gg.fill(cx - 1, cy + inner, cx + 2, cy + outer, th);
        gg.fill(cx - 1, cy - outer, cx + 2, cy - inner, th); // sniper keeps all four arms
        for (int i = 1; i <= (builtIn == 5 ? 7 : 4); i++) { // mil dots
            int d = (int) (r * 0.065f * i);
            gg.fill(cx - d - 1, cy - 1, cx - d + 1, cy + 2, th);
            gg.fill(cx + d - 1, cy - 1, cx + d + 1, cy + 2, th);
            gg.fill(cx - 1, cy + d - 1, cx + 2, cy + d + 1, th);
            gg.fill(cx - 1, cy - d - 1, cx + 2, cy - d + 1, th);
        }
        gg.fill(cx - 1, cy - 1, cx + 1, cy + 1, 0xFFFF2828); // illuminated centre
    }

    // ------------------------------------------------------------------ HUD
    @SubscribeEvent
    public static void onHud(RenderGuiEvent.Post e) {
        Minecraft mc = Minecraft.getInstance();
        LocalPlayer p = mc.player;
        if (p == null || mc.options.hideGui) return;
        GuiGraphics gg = e.getGuiGraphics();
        Font font = mc.font;
        int w = gg.guiWidth();
        int h = gg.guiHeight();

        drawFeed(gg, font, w);

        ItemStack st = p.getMainHandItem();
        if (!(st.getItem() instanceof GunItem g)) return;

        // ---- armour bar (bottom-left)
        int armor = Math.min(20, p.getArmorValue());
        GunUi.text(gg, font, "ARMOR", 12, h - 30, 0.8f, 0xFFB8C0CC);
        for (int i = 0; i < 10; i++) {
            int x = 12 + i * 6;
            gg.fill(x, h - 19, x + 5, h - 16, 0x80000000);
            if (armor >= (i + 1) * 2) gg.fill(x, h - 19, x + 5, h - 16, 0xFF58B8F0);
            else if (armor == i * 2 + 1) gg.fill(x, h - 19, x + 3, h - 16, 0xFF58B8F0);
        }

        // ---- ammo block (bottom-right)
        int ammo = GunItem.getAmmo(st, g.type);
        int reload = GunItem.getReload(st);
        boolean reloading = reload > 0;
        boolean creative = p.getAbilities().instabuild;
        String reserve = creative ? "∞" : String.valueOf(GunItem.countAmmo(p, g.type));
        int right = w - 14;
        int base = h - 20;
        GunUi.textRight(gg, font, st.getHoverName().getString(), right, base - 50, 0.85f, 0xFFD5D9E0);
        gg.fill(right - 96, base - 39, right, base - 38, 0x80FFFFFF);
        if (reloading) {
            GunUi.textRight(gg, font, "RELOADING", right, base - 34, 1.2f, 0xFFB8C0CC);
            int bw = 96;
            float f = 1f - (float) reload / Math.max(1, g.type.reloadTicks);
            gg.fill(right - bw, base - 14, right, base - 11, 0x80000000);
            gg.fill(right - bw, base - 14, right - bw + (int) (bw * f), base - 11, GunUi.AMBER);
        } else {
            boolean low = ammo <= Math.max(1, g.type.magSize / 5);
            String a = String.valueOf(ammo);
            float sc = 2.6f;
            int sepX = right - 46;
            GunUi.textRight(gg, font, a, sepX - 5, base - 34, sc, low ? 0xFFFF5A4A : 0xFFFFFFFF);
            gg.fill(sepX, base - 33, sepX + 1, base - 12, 0x90FFFFFF);
            GunUi.text(gg, font, "/" + g.type.magSize, sepX + 5, base - 32, 0.95f, 0xFFD5D9E0);
            GunUi.text(gg, font, reserve, sepX + 5, base - 20, 1.1f, 0xFF9AA2AE);
        }
        // pips + fire mode
        int filled = Math.round(4f * ammo / Math.max(1, g.type.magSize));
        for (int i = 0; i < 4; i++) {
            gg.fill(right - 96 + i * 4, base - 6, right - 96 + i * 4 + 2, base + 3, i < filled ? 0xFFFFFFFF : 0x60FFFFFF);
        }
        GunUi.text(gg, font, g.type.automatic ? "AUTO" : "SEMI", right - 76, base - 4, 0.9f, 0xFFD5D9E0);

        // ---- hit feedback
        int cx = w / 2;
        int cy = h / 2;
        if (hitTimer > 0) {
            String s = Math.round(hitDmg) + " dmg / " + hitCount + " hits";
            int a = Math.min(255, hitTimer * 10);
            int col = (a << 24) | 0xFFC040;
            GunUi.text(gg, font, s, cx - font.width(s) * 0.5f * 0.95f, cy - 56, 0.95f, col);
        }
        for (float[] f : FLOATERS) {
            float t = f[2] / 26f;
            int a = (int) (255 * (1f - t));
            if (a < 8) continue;
            int col = (a << 24) | (f[1] > 0 ? 0xFFE060 : 0xFFFFFF);
            String s = String.format(Locale.ROOT, "%.1f", f[0]);
            GunUi.text(gg, font, s, cx + 10 + f[3], cy - 16 + f[4] - f[2] * 0.7f, 0.9f, col);
        }
        if (markerTimer > 0) {
            int mc2 = markerHead ? 0xFFFF4040 : 0xFFFFFFFF;
            int d = 5 + (6 - markerTimer);
            PoseStack ps = gg.pose();
            ps.pushPose();
            ps.translate(cx + 0.5f, cy + 0.5f, 0);
            for (int q = 0; q < 4; q++) {
                ps.pushPose();
                ps.mulPose(Axis.ZP.rotationDegrees(45f + 90f * q));
                gg.fill(d, 0, d + 4, 1, mc2);
                ps.popPose();
            }
            ps.popPose();
        }
    }
}
