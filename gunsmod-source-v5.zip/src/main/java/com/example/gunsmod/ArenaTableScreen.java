package com.example.gunsmod;

import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.screens.inventory.AbstractContainerScreen;
import net.minecraft.network.chat.Component;
import net.minecraft.world.entity.player.Inventory;

public class ArenaTableScreen extends AbstractContainerScreen<ArenaTableMenu> {
    public ArenaTableScreen(ArenaTableMenu menu, Inventory inv, Component title) {
        super(menu, inv, title);
    }

    @Override
    protected void init() {
        this.imageWidth = this.width;
        this.imageHeight = this.height;
        super.init();
        this.leftPos = 0;
        this.topPos = 0;
    }

    @Override
    protected void renderLabels(GuiGraphics g, int mx, int my) {
    }

    private int cx() {
        return width / 2;
    }

    private int rowY(int i) {
        return 54 + i * 30;
    }

    private void button(GuiGraphics g, int x, int y, int w, int h, String s, int mx, int my, int col) {
        boolean hov = mx >= x && mx < x + w && my >= y && my < y + h;
        g.fill(x, y, x + w, y + h, hov ? 0xFFFFFFFF & (col | 0x00202020) : col);
        g.drawString(font, s, x + (w - font.width(s)) / 2, y + (h - 8) / 2, 0xFF14100A, false);
    }

    @Override
    protected void renderBg(GuiGraphics g, float pt, int mx, int my) {
        GunUi.background(g, width, height);
        GunUi.label(g, font, "BATTLE ARENA", 10, 9);
        GunUi.text(g, font, "Match Table", 10, 20, 1.7f, GunUi.TXT);
        boolean running = menu.data.get(3) == 1;
        int c = cx();
        GunUi.panel(g, c - 130, 40, c + 130, 40 + 3 * 30 + 6);
        String[] names = {"Team size", "Match time", "Kills to win"};
        String[] vals = {menu.data.get(0) + " vs " + menu.data.get(0), menu.data.get(1) + " min", String.valueOf(menu.data.get(2))};
        for (int i = 0; i < 3; i++) {
            int y = rowY(i) - 8;
            GunUi.text(g, font, names[i], c - 120, y + 5, 0.95f, GunUi.DIM);
            GunUi.textRight(g, font, vals[i], c + 40, y + 5, 1.1f, GunUi.TXT);
            button(g, c + 56, y, 28, 18, "-", mx, my, running ? 0xFF4A4F58 : GunUi.AMBER);
            button(g, c + 90, y, 28, 18, "+", mx, my, running ? 0xFF4A4F58 : GunUi.AMBER);
        }
        int by = 40 + 3 * 30 + 16;
        if (!running) {
            button(g, c - 130, by, 126, 24, "WATCH  AI vs AI", mx, my, 0xFF6CB8E8);
            button(g, c + 4, by, 126, 24, "PLAY  (red team)", mx, my, 0xFFE86C6C);
        } else {
            button(g, c - 130, by, 260, 24, "STOP MATCH", mx, my, 0xFFE05A4A);
            int s = menu.data.get(6);
            String sc = "RED  " + menu.data.get(4) + "  -  " + menu.data.get(5) + "  GREEN";
            GunUi.text(g, font, sc, c - font.width(sc) * 1.6f * 0.5f, by + 34, 1.6f, GunUi.TXT);
            String t = (s / 60) + ":" + (s % 60 < 10 ? "0" : "") + (s % 60) + (menu.data.get(7) == 1 ? "   (you play for RED)" : "   (spectating)");
            GunUi.text(g, font, t, c - font.width(t) * 0.5f, by + 56, 1.0f, GunUi.AMBER);
        }
    }

    @Override
    public void render(GuiGraphics g, int mx, int my, float pt) {
        super.render(g, mx, my, pt);
    }

    private boolean hit(double mx, double my, int x, int y, int w, int h) {
        return mx >= x && mx < x + w && my >= y && my < y + h;
    }

    private void click(int id) {
        if (minecraft != null && minecraft.gameMode != null) minecraft.gameMode.handleInventoryButtonClick(menu.containerId, id);
    }

    @Override
    public boolean mouseClicked(double mx, double my, int button) {
        int c = cx();
        boolean running = menu.data.get(3) == 1;
        if (!running) {
            for (int i = 0; i < 3; i++) {
                int y = rowY(i) - 8;
                if (hit(mx, my, c + 56, y, 28, 18)) { click(i * 2); return true; }
                if (hit(mx, my, c + 90, y, 28, 18)) { click(i * 2 + 1); return true; }
            }
        }
        int by = 40 + 3 * 30 + 16;
        if (!running) {
            if (hit(mx, my, c - 130, by, 126, 24)) { click(10); onClose(); return true; }
            if (hit(mx, my, c + 4, by, 126, 24)) { click(11); onClose(); return true; }
        } else if (hit(mx, my, c - 130, by, 260, 24)) {
            click(12);
            return true;
        }
        return super.mouseClicked(mx, my, button);
    }
}
