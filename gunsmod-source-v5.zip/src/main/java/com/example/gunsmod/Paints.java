package com.example.gunsmod;

/** Gun finishes: 0-6 plain colours, 7+ patterned skins (22-27 also glow). */
public final class Paints {
    public static final String[] NAMES = {"Graphite", "Desert Tan", "Jungle Camo", "Arctic White", "Crimson Red", "Ocean Blue", "Gold Plated", "Digital Camo", "Woodland Camo", "Desert Camo", "Arctic Camo", "Urban Camo", "Tiger Stripes", "Dragon Scales", "Carbon Fiber", "Chrome Gold", "Hex Armor", "Skull Pattern", "Inferno", "Ice Crystal", "Racing Checker", "Hazard Stripes", "Cyber Neon", "Neon Circuit", "Matrix Code", "Synthwave", "Lava Cracks", "Galaxy"};
    public static final int[] COLORS = {0x003C3C42, 0x00B0925C, 0x004A6234, 0x00E1E4E8, 0x00A62626, 0x003060AA, 0x00D6AA32, 0xFF5B6C42, 0xFF3A3923, 0xFF9E8153, 0xFFB3BAC5, 0xFF44464B, 0xFF894816, 0xFFA83A20, 0xFF323236, 0xFFCC9F31, 0xFF1A3F78, 0xFF50504E, 0xFFB15A1A, 0xFFC8E4F6, 0xFF7F430F, 0xFF866D0E, 0xFF0D2735, 0xFF2F0D0E, 0xFF041407, 0xFF812D98, 0xFF422714, 0xFF261152};
    public static final boolean[] GLOW = {false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, true, true, true, true, true, true};
    public static final int COUNT = NAMES.length;

    private Paints() {}
}
