package com.example.gunsmod;

import java.util.Set;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;
import net.minecraft.core.particles.ParticleType;
import net.minecraft.core.particles.SimpleParticleType;
import net.minecraft.core.registries.Registries;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.MobCategory;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.inventory.ContainerLevelAccess;
import net.minecraft.world.inventory.MenuType;
import net.minecraft.world.item.BlockItem;
import net.minecraft.world.item.CreativeModeTab;
import net.minecraft.world.level.block.SoundType;
import net.minecraft.world.level.block.entity.BlockEntityType;
import net.minecraft.world.level.block.state.BlockBehaviour;
import net.minecraft.world.level.material.MapColor;
import net.neoforged.neoforge.common.extensions.IMenuTypeExtension;
import net.neoforged.neoforge.registries.DeferredBlock;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.neoforged.bus.api.IEventBus;
import net.neoforged.fml.common.Mod;
import net.neoforged.neoforge.common.NeoForge;
import net.neoforged.neoforge.event.entity.EntityAttributeCreationEvent;
import net.neoforged.neoforge.event.entity.player.PlayerEvent;
import net.neoforged.neoforge.network.event.RegisterPayloadHandlersEvent;
import net.neoforged.neoforge.network.registration.PayloadRegistrar;
import net.neoforged.neoforge.registries.DeferredHolder;
import net.neoforged.neoforge.registries.DeferredItem;
import net.neoforged.neoforge.registries.DeferredRegister;

@Mod(GunsMod.MODID)
public class GunsMod {
    public static final String MODID = "gunsmod";

    public static final DeferredRegister.Items ITEMS = DeferredRegister.createItems(MODID);
    public static final DeferredRegister.Blocks BLOCKS = DeferredRegister.createBlocks(MODID);
    public static final DeferredRegister<MenuType<?>> MENUS = DeferredRegister.create(Registries.MENU, MODID);
    public static final DeferredRegister<EntityType<?>> ENTITIES = DeferredRegister.create(Registries.ENTITY_TYPE, MODID);
    public static final DeferredRegister<ParticleType<?>> PARTICLES = DeferredRegister.create(Registries.PARTICLE_TYPE, MODID);
    public static final DeferredHolder<ParticleType<?>, SimpleParticleType> P_SMOKE_S = PARTICLES.register("gun_smoke_s", () -> new SimpleParticleType(false));
    public static final DeferredHolder<ParticleType<?>, SimpleParticleType> P_SMOKE_M = PARTICLES.register("gun_smoke_m", () -> new SimpleParticleType(false));
    public static final DeferredHolder<ParticleType<?>, SimpleParticleType> P_SMOKE_L = PARTICLES.register("gun_smoke_l", () -> new SimpleParticleType(true));
    public static final DeferredHolder<ParticleType<?>, SimpleParticleType> P_DUST = PARTICLES.register("gun_dust", () -> new SimpleParticleType(false));
    public static final DeferredHolder<ParticleType<?>, SimpleParticleType> P_FLASH_S = PARTICLES.register("gun_flash_s", () -> new SimpleParticleType(false));
    public static final DeferredHolder<ParticleType<?>, SimpleParticleType> P_FLASH_L = PARTICLES.register("gun_flash_l", () -> new SimpleParticleType(true));
    public static final DeferredHolder<ParticleType<?>, SimpleParticleType> P_SPARK = PARTICLES.register("gun_spark", () -> new SimpleParticleType(false));
    public static final DeferredHolder<ParticleType<?>, SimpleParticleType> P_FIRE = PARTICLES.register("gun_fire", () -> new SimpleParticleType(true));
    public static final DeferredRegister<BlockEntityType<?>> BLOCK_ENTITIES = DeferredRegister.create(Registries.BLOCK_ENTITY_TYPE, MODID);
    public static final DeferredRegister<CreativeModeTab> TABS = DeferredRegister.create(Registries.CREATIVE_MODE_TAB, MODID);

    public static final DeferredBlock<GunWorkbenchBlock> WORKBENCH = BLOCKS.registerBlock("gun_workbench",
            GunWorkbenchBlock::new, BlockBehaviour.Properties.of().mapColor(MapColor.METAL).strength(3.5f).sound(SoundType.METAL));
    public static final DeferredBlock<GunCustomizerBlock> CUSTOMIZER = BLOCKS.registerBlock("gun_customizer",
            GunCustomizerBlock::new, BlockBehaviour.Properties.of().mapColor(MapColor.METAL).strength(3.5f).sound(SoundType.METAL));
    public static final DeferredItem<BlockItem> WORKBENCH_ITEM = ITEMS.registerSimpleBlockItem("gun_workbench", WORKBENCH);
    public static final DeferredItem<BlockItem> CUSTOMIZER_ITEM = ITEMS.registerSimpleBlockItem("gun_customizer", CUSTOMIZER);

    public static final DeferredHolder<MenuType<?>, MenuType<GunWorkbenchMenu>> WORKBENCH_MENU = MENUS.register("gun_workbench",
            () -> IMenuTypeExtension.create((id, inv, buf) -> new GunWorkbenchMenu(id, inv, ContainerLevelAccess.NULL)));
    public static final DeferredHolder<MenuType<?>, MenuType<GunCustomizerMenu>> CUSTOMIZER_MENU = MENUS.register("gun_customizer",
            () -> IMenuTypeExtension.create((id, inv, buf) -> new GunCustomizerMenu(id, inv, ContainerLevelAccess.NULL)));

    public static final DeferredBlock<BotRespawnerBlock> RESPAWNER = BLOCKS.registerBlock("bot_respawner",
            BotRespawnerBlock::new, BlockBehaviour.Properties.of().mapColor(MapColor.METAL).strength(3.5f).sound(SoundType.METAL));
    public static final DeferredItem<BlockItem> RESPAWNER_ITEM = ITEMS.registerSimpleBlockItem("bot_respawner", RESPAWNER);
    public static final DeferredHolder<BlockEntityType<?>, BlockEntityType<RespawnerBlockEntity>> RESPAWNER_BE =
            BLOCK_ENTITIES.register("bot_respawner", () -> BlockEntityType.Builder.of(RespawnerBlockEntity::new, RESPAWNER.get()).build(null));
    public static final DeferredHolder<MenuType<?>, MenuType<RespawnerMenu>> RESPAWNER_MENU = MENUS.register("bot_respawner",
            () -> IMenuTypeExtension.create((id, inv, buf) -> new RespawnerMenu(id, inv)));

    public static final DeferredBlock<ArenaTableBlock> ARENA_TABLE = BLOCKS.registerBlock("arena_table",
            ArenaTableBlock::new, BlockBehaviour.Properties.of().mapColor(MapColor.METAL).strength(-1.0f, 3600000.0f).sound(SoundType.METAL));
    public static final DeferredItem<BlockItem> ARENA_TABLE_ITEM = ITEMS.registerSimpleBlockItem("arena_table", ARENA_TABLE);
    public static final DeferredHolder<BlockEntityType<?>, BlockEntityType<ArenaTableBlockEntity>> ARENA_BE =
            BLOCK_ENTITIES.register("arena_table", () -> BlockEntityType.Builder.of(ArenaTableBlockEntity::new, ARENA_TABLE.get()).build(null));
    public static final DeferredHolder<MenuType<?>, MenuType<ArenaTableMenu>> ARENA_MENU = MENUS.register("arena_table",
            () -> IMenuTypeExtension.create((id, inv, buf) -> new ArenaTableMenu(id, inv)));
    public static final DeferredItem<ArenaWandItem> ARENA_WAND = ITEMS.registerItem("arena_wand", ArenaWandItem::new);

    public static final DeferredItem<GrenadeItem> GRENADE = ITEMS.registerItem("grenade", GrenadeItem::new);
    public static final DeferredItem<CrystalItem> CRYSTAL_WHITE = ITEMS.registerItem("crystal_white", p -> new CrystalItem(p, CrystalItem.Kind.WHITE));
    public static final DeferredItem<CrystalItem> CRYSTAL_PURPLE = ITEMS.registerItem("crystal_purple", p -> new CrystalItem(p, CrystalItem.Kind.PURPLE));
    public static final DeferredItem<CrystalItem> CRYSTAL_GREEN = ITEMS.registerItem("crystal_green", p -> new CrystalItem(p, CrystalItem.Kind.GREEN));
    public static final DeferredItem<CrystalItem> CRYSTAL_RED = ITEMS.registerItem("crystal_red", p -> new CrystalItem(p, CrystalItem.Kind.RED));
    public static final DeferredItem<MedkitItem> MEDKIT = ITEMS.registerItem("medkit", MedkitItem::new);
    public static final DeferredHolder<EntityType<?>, EntityType<GrenadeEntity>> GRENADE_ENTITY =
            ENTITIES.register("grenade", () -> EntityType.Builder.<GrenadeEntity>of(GrenadeEntity::new, MobCategory.MISC)
                    .sized(0.3f, 0.3f).clientTrackingRange(4).updateInterval(10).build("grenade"));

    /** Old universal bullets (kept registered so existing worlds load; no gun uses it any more). */
    public static final DeferredItem<Item> AMMO = ITEMS.registerItem("ammo", Item::new);

    /** One dedicated ammo item per gun (ammo_pistol, ammo_deagle, ...). */
    public static final java.util.Map<GunType, DeferredItem<Item>> AMMO_ITEMS = new java.util.EnumMap<>(GunType.class);
    static {
        for (GunType t : GunType.values()) AMMO_ITEMS.put(t, ITEMS.registerItem("ammo_" + t.id, Item::new));
    }

    public static final DeferredItem<GunItem> PISTOL = ITEMS.registerItem("pistol", p -> new GunItem(p, GunType.PISTOL));
    public static final DeferredItem<GunItem> SMG = ITEMS.registerItem("smg", p -> new GunItem(p, GunType.SMG));
    public static final DeferredItem<GunItem> RIFLE = ITEMS.registerItem("rifle", p -> new GunItem(p, GunType.RIFLE));
    public static final DeferredItem<GunItem> SHOTGUN = ITEMS.registerItem("shotgun", p -> new GunItem(p, GunType.SHOTGUN));
    public static final DeferredItem<GunItem> SNIPER = ITEMS.registerItem("sniper", p -> new GunItem(p, GunType.SNIPER));
    public static final DeferredItem<GunItem> DEAGLE = ITEMS.registerItem("deagle", p -> new GunItem(p, GunType.DEAGLE));
    public static final DeferredItem<GunItem> M4 = ITEMS.registerItem("m4", p -> new GunItem(p, GunType.M4));
    public static final DeferredItem<GunItem> LMG = ITEMS.registerItem("lmg", p -> new GunItem(p, GunType.LMG));
    public static final DeferredItem<GunItem> RPG = ITEMS.registerItem("rpg", p -> new GunItem(p, GunType.RPG));
    public static final DeferredItem<GunItem> MINIGUN = ITEMS.registerItem("minigun", p -> new GunItem(p, GunType.MINIGUN));

    public static final DeferredItem<BotSpawnerItem> ALLY_SPAWNER =
            ITEMS.registerItem("ally_bot_spawner", p -> new BotSpawnerItem(p, true));
    public static final DeferredItem<BotSpawnerItem> ENEMY_SPAWNER =
            ITEMS.registerItem("enemy_bot_spawner", p -> new BotSpawnerItem(p, false));

    public static final DeferredHolder<EntityType<?>, EntityType<GunBotEntity>> GUN_BOT =
            ENTITIES.register("gun_bot", () -> EntityType.Builder.of(GunBotEntity::new, MobCategory.CREATURE)
                    .sized(0.6f, 1.8f).clientTrackingRange(10).build("gun_bot"));

    public static final DeferredHolder<CreativeModeTab, CreativeModeTab> TAB = TABS.register("main", () ->
            CreativeModeTab.builder()
                    .title(Component.translatable("itemGroup.gunsmod"))
                    .icon(() -> new ItemStack(RIFLE.get()))
                    .displayItems((params, output) -> ITEMS.getEntries().forEach(h -> output.accept(h.get())))
                    .build());

    /** Players currently aiming (server side). */
    public static GunItem gunItem(GunType t) {
        return switch (t) {
            case PISTOL -> PISTOL.get();
            case DEAGLE -> DEAGLE.get();
            case SMG -> SMG.get();
            case RIFLE -> RIFLE.get();
            case M4 -> M4.get();
            case SHOTGUN -> SHOTGUN.get();
            case SNIPER -> SNIPER.get();
            case LMG -> LMG.get();
            case RPG -> RPG.get();
            default -> MINIGUN.get();
        };
    }

    public static final Set<UUID> AIMING = ConcurrentHashMap.newKeySet();

    public static boolean isAiming(Player player) {
        return AIMING.contains(player.getUUID());
    }

    public GunsMod(IEventBus modBus) {
        BLOCKS.register(modBus);
        BLOCK_ENTITIES.register(modBus);
        MENUS.register(modBus);
        ITEMS.register(modBus);
        ENTITIES.register(modBus);
        TABS.register(modBus);
        PARTICLES.register(modBus);
        modBus.addListener(this::registerPayloads);
        modBus.addListener(this::registerAttributes);
        NeoForge.EVENT_BUS.addListener((PlayerEvent.PlayerLoggedOutEvent e) -> AIMING.remove(e.getEntity().getUUID()));
    }

    private void registerAttributes(EntityAttributeCreationEvent event) {
        event.put(GUN_BOT.get(), GunBotEntity.createAttributes().build());
    }

    private void registerPayloads(RegisterPayloadHandlersEvent event) {
        PayloadRegistrar reg = event.registrar("1");
        reg.playToServer(ReloadPayload.TYPE, ReloadPayload.CODEC, (payload, ctx) -> ctx.enqueueWork(() -> {
            if (ctx.player() instanceof ServerPlayer sp) {
                ItemStack s = sp.getMainHandItem();
                if (s.getItem() instanceof GunItem) {
                    GunItem.startReload(sp, s);
                }
            }
        }));
        reg.playToClient(KillFeedPayload.TYPE, KillFeedPayload.CODEC, (payload, ctx) -> ctx.enqueueWork(
                () -> ClientGameEvents.onKillFeed(payload)));
        reg.playToClient(HitPayload.TYPE, HitPayload.CODEC, (payload, ctx) -> ctx.enqueueWork(
                () -> ClientGameEvents.onHit(payload.damage(), payload.head())));
        reg.playToServer(AimPayload.TYPE, AimPayload.CODEC, (payload, ctx) -> ctx.enqueueWork(() -> {
            if (ctx.player() instanceof ServerPlayer sp) {
                if (payload.aiming()) {
                    AIMING.add(sp.getUUID());
                } else {
                    AIMING.remove(sp.getUUID());
                }
            }
        }));
    }
}
