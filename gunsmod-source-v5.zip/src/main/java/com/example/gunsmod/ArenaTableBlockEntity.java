package com.example.gunsmod;

import java.util.ArrayList;
import java.util.List;
import java.util.UUID;
import net.minecraft.core.BlockPos;
import net.minecraft.core.HolderLookup;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.nbt.LongArrayTag;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.inventory.ContainerData;
import net.minecraft.world.level.GameType;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.AABB;

/** Match controller of a battle arena: settings, spawning, scoring, respawns and the end of the match. */
public class ArenaTableBlockEntity extends BlockEntity implements BotHost {
    private BlockPos origin = BlockPos.ZERO; // north-west floor corner of the 30x30 arena
    private final List<BlockPos> redSpawns = new ArrayList<>();
    private final List<BlockPos> greenSpawns = new ArrayList<>();
    private int teamSize = 3;
    private int minutes = 3;
    private int killLimit = 20;

    private boolean running;
    private boolean play;
    private int redKills, greenKills, ticksLeft;
    private final List<UUID> redBots = new ArrayList<>();
    private final List<UUID> greenBots = new ArrayList<>();
    private final List<int[]> queue = new ArrayList<>();
    private UUID playerId;
    private int prevMode;
    private boolean cleaned;

    public final ContainerData data = new ContainerData() {
        @Override
        public int get(int i) {
            return switch (i) {
                case 0 -> teamSize;
                case 1 -> minutes;
                case 2 -> killLimit;
                case 3 -> running ? 1 : 0;
                case 4 -> redKills;
                case 5 -> greenKills;
                case 6 -> Math.max(0, ticksLeft / 20);
                default -> play ? 1 : 0;
            };
        }

        @Override
        public void set(int i, int v) {
        }

        @Override
        public int getCount() {
            return 8;
        }
    };

    public ArenaTableBlockEntity(BlockPos pos, BlockState state) {
        super(GunsMod.ARENA_BE.get(), pos, state);
    }

    public void configure(BlockPos origin, List<BlockPos> red, List<BlockPos> green) {
        this.origin = origin;
        redSpawns.clear();
        redSpawns.addAll(red);
        greenSpawns.clear();
        greenSpawns.addAll(green);
        setChanged();
    }

    private AABB bounds() {
        return new AABB(origin.getX(), origin.getY() - 2, origin.getZ(), origin.getX() + 30, origin.getY() + 14, origin.getZ() + 30);
    }

    // ------------------------------------------------------------ settings (server side)
    public void adjust(int which, int delta) {
        if (running) return;
        switch (which) {
            case 0 -> teamSize = Math.max(1, Math.min(5, teamSize + delta));
            case 1 -> minutes = Math.max(1, Math.min(30, minutes + delta));
            default -> killLimit = Math.max(5, Math.min(100, killLimit + delta * 5));
        }
        setChanged();
    }

    public boolean isRunning() {
        return running;
    }

    // ------------------------------------------------------------ match flow
    public void start(ServerPlayer sp, boolean playMode) {
        if (!(level instanceof ServerLevel sl) || running) return;
        if (redSpawns.isEmpty() || greenSpawns.isEmpty()) {
            sp.displayClientMessage(Component.literal("This arena has no spawn points"), true);
            return;
        }
        cleanupBots(sl);
        redKills = 0;
        greenKills = 0;
        ticksLeft = minutes * 60 * 20;
        queue.clear();
        play = playMode;
        playerId = sp.getUUID();
        running = true;
        int redCount = playMode ? teamSize - 1 : teamSize;
        for (int i = 0; i < redCount; i++) spawnBot(0);
        for (int i = 0; i < teamSize; i++) spawnBot(1);
        if (playMode) {
            ArenaManager.join(sp.getUUID(), this);
            BlockPos p = redSpawns.get(0);
            sp.setHealth(sp.getMaxHealth());
            sp.teleportTo(sl, p.getX() + 0.5, p.getY(), p.getZ() + 0.5, -90f, 0f);
        } else {
            prevMode = sp.gameMode.getGameModeForPlayer().getId();
            sp.setGameMode(GameType.SPECTATOR);
            sp.teleportTo(sl, origin.getX() + 15.0, origin.getY() + 12.0, origin.getZ() + 15.0, 0f, 35f);
        }
        ArenaManager.tellAll(sl, Component.literal("Match started: " + teamSize + " vs " + teamSize + " - first to " + killLimit
                + " kills or " + minutes + " min"));
        setChanged();
    }

    public void stopByUser() {
        if (level instanceof ServerLevel sl && running) end(sl, true);
    }

    private void end(ServerLevel sl, boolean aborted) {
        running = false;
        String res = aborted ? "Match stopped" : redKills > greenKills ? "RED team wins " + redKills + " - " + greenKills
                : greenKills > redKills ? "GREEN team wins " + greenKills + " - " + redKills : "Draw " + redKills + " - " + greenKills;
        ArenaManager.tellAll(sl, Component.literal(res));
        cleanupBots(sl);
        queue.clear();
        if (playerId != null) {
            ArenaManager.leave(playerId);
            if (sl.getServer().getPlayerList().getPlayer(playerId) instanceof ServerPlayer sp) {
                if (!play) sp.setGameMode(GameType.byId(prevMode));
                sp.teleportTo(sl, worldPosition.getX() + 0.5, worldPosition.getY() + 1.0, worldPosition.getZ() + 2.5, 0f, 0f);
            }
        }
        playerId = null;
        setChanged();
    }

    private void cleanupBots(ServerLevel sl) {
        for (GunBotEntity b : sl.getEntitiesOfClass(GunBotEntity.class, bounds().inflate(40))) {
            if (b.isMachineBound()) b.discard();
        }
        redBots.clear();
        greenBots.clear();
    }

    private void spawnBot(int team) {
        if (!(level instanceof ServerLevel sl)) return;
        List<BlockPos> spots = team == 0 ? redSpawns : greenSpawns;
        BlockPos p = spots.get(sl.random.nextInt(spots.size()));
        GunBotEntity bot = GunsMod.GUN_BOT.get().create(sl);
        if (bot == null) return;
        bot.moveTo(p.getX() + 0.5, p.getY(), p.getZ() + 0.5, team == 0 ? -90f : 90f, 0f);
        bot.importData(RandomLoadout.make(sl.random, team == 1, sl.registryAccess()), sl.registryAccess());
        bot.setNoLoot(true);
        bot.setMachinePos(worldPosition);
        sl.addFreshEntity(bot);
        (team == 0 ? redBots : greenBots).add(bot.getUUID());
    }

    // ------------------------------------------------------------ hooks
    public void onBotKilled(GunBotEntity bot, Entity killer) {
        if (!running) return;
        score(killer);
    }

    public void onPlayerKilled(ServerPlayer sp, Entity killer) {
        if (!running || !(level instanceof ServerLevel sl)) return;
        score(killer);
        BlockPos p = redSpawns.get(sl.random.nextInt(redSpawns.size()));
        sp.teleportTo(sl, p.getX() + 0.5, p.getY(), p.getZ() + 0.5, -90f, 0f);
    }

    private void score(Entity killer) {
        if (killer instanceof GunBotEntity kb) {
            if (kb.isAlly()) greenKills++; else redKills++;
        } else if (killer instanceof Player p && ArenaManager.isRed(p.getUUID())) {
            redKills++;
        }
    }

    @Override
    public void onBotGone(UUID id) {
        boolean r = redBots.remove(id);
        boolean g = greenBots.remove(id);
        if (running && (r || g)) queue.add(new int[]{r ? 0 : 1, 100}); // back in 5 seconds
    }

    // ------------------------------------------------------------ tick
    public void serverTick() {
        if (!(level instanceof ServerLevel sl)) return;
        if (!cleaned) {
            cleaned = true;
            cleanupBots(sl);
        }
        if (!running) return;
        if (--ticksLeft <= 0 || redKills >= killLimit || greenKills >= killLimit) {
            end(sl, false);
            return;
        }
        for (int i = queue.size() - 1; i >= 0; i--) {
            int[] q = queue.get(i);
            if (--q[1] <= 0) {
                queue.remove(i);
                spawnBot(q[0]);
            }
        }
        if (ticksLeft % 20 == 0) {
            int s = ticksLeft / 20;
            Component c = Component.literal("RED " + redKills + "  -  " + greenKills + " GREEN     "
                    + (s / 60) + ":" + (s % 60 < 10 ? "0" : "") + (s % 60) + "   (first to " + killLimit + ")");
            for (ServerPlayer p : sl.players()) {
                if (p.distanceToSqr(worldPosition.getX(), worldPosition.getY(), worldPosition.getZ()) < 3600.0) {
                    p.displayClientMessage(c, true);
                }
            }
        }
        if (play && playerId != null && sl.getServer().getPlayerList().getPlayer(playerId) == null) end(sl, true);
    }

    // ------------------------------------------------------------ save
    private static LongArrayTag longs(List<BlockPos> l) {
        long[] a = new long[l.size()];
        for (int i = 0; i < a.length; i++) a[i] = l.get(i).asLong();
        return new LongArrayTag(a);
    }

    @Override
    protected void saveAdditional(CompoundTag tag, HolderLookup.Provider reg) {
        super.saveAdditional(tag, reg);
        tag.putLong("Origin", origin.asLong());
        tag.put("Red", longs(redSpawns));
        tag.put("Green", longs(greenSpawns));
        tag.putInt("Team", teamSize);
        tag.putInt("Min", minutes);
        tag.putInt("Kills", killLimit);
    }

    @Override
    protected void loadAdditional(CompoundTag tag, HolderLookup.Provider reg) {
        super.loadAdditional(tag, reg);
        origin = BlockPos.of(tag.getLong("Origin"));
        redSpawns.clear();
        for (long l : tag.getLongArray("Red")) redSpawns.add(BlockPos.of(l));
        greenSpawns.clear();
        for (long l : tag.getLongArray("Green")) greenSpawns.add(BlockPos.of(l));
        teamSize = tag.contains("Team") ? tag.getInt("Team") : 3;
        minutes = tag.contains("Min") ? tag.getInt("Min") : 3;
        killLimit = tag.contains("Kills") ? tag.getInt("Kills") : 20;
        running = false;
    }
}
