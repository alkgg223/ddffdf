package com.example.gunsmod;

import java.util.ArrayList;
import java.util.List;
import java.util.UUID;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.core.HolderLookup;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.nbt.ListTag;
import net.minecraft.nbt.NbtUtils;
import net.minecraft.nbt.Tag;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.ContainerHelper;
import net.minecraft.world.SimpleContainer;
import net.minecraft.world.inventory.ContainerData;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.state.BlockState;

/** Keeps up to {@code max} bots (stored in the purple crystal) alive next to the block. */
public class RespawnerBlockEntity extends BlockEntity implements BotHost {
    public final SimpleContainer container = new SimpleContainer(1);
    private int max = 3;
    private final List<UUID> alive = new ArrayList<>();
    private int cooldown = 60;

    public final ContainerData data = new ContainerData() {
        @Override
        public int get(int i) {
            return switch (i) { case 0 -> max; case 1 -> alive.size(); default -> cooldown / 20; };
        }

        @Override
        public void set(int i, int v) {
            if (i == 0) {
                max = Math.max(1, Math.min(20, v));
                setChanged();
            }
        }

        @Override
        public int getCount() {
            return 3;
        }
    };

    public RespawnerBlockEntity(BlockPos pos, BlockState state) {
        super(GunsMod.RESPAWNER_BE.get(), pos, state);
        container.addListener(c -> setChanged());
    }

    @Override
    public void onBotGone(UUID id) {
        if (alive.remove(id)) {
            cooldown = Math.max(cooldown, 100); // 5 s before the replacement appears
            setChanged();
        }
    }

    public void serverTick() {
        if (!(level instanceof ServerLevel sl)) return;
        if (cooldown > 0) cooldown--;
        // forget bots that no longer exist in a loaded world (removed some other way)
        if (sl.getGameTime() % 40 == 0) {
            alive.removeIf(id -> {
                var e = sl.getEntity(id);
                return e != null && !e.isAlive();
            });
        }
        ItemStack crystal = container.getItem(0);
        if (!(crystal.getItem() instanceof CrystalItem ci) || !ci.usableInRespawner() || alive.size() >= max || cooldown > 0) return;
        CompoundTag d = CrystalItem.spawnData(crystal, sl);
        if (d.isEmpty()) return;
        BlockPos spot = findSpot(sl);
        if (spot == null) {
            cooldown = 40;
            return;
        }
        GunBotEntity bot = GunsMod.GUN_BOT.get().create(sl);
        if (bot == null) return;
        bot.moveTo(spot.getX() + 0.5, spot.getY(), spot.getZ() + 0.5, sl.random.nextFloat() * 360f, 0f);
        bot.importData(d, sl.registryAccess());
        bot.setNoLoot(true);
        bot.setMachinePos(worldPosition);
        sl.addFreshEntity(bot);
        alive.add(bot.getUUID());
        cooldown = 20;
        setChanged();
    }

    private BlockPos findSpot(ServerLevel sl) {
        List<BlockPos> opts = new ArrayList<>();
        for (int dx = -2; dx <= 2; dx++) {
            for (int dz = -2; dz <= 2; dz++) {
                if (Math.abs(dx) < 1 && Math.abs(dz) < 1) continue;
                for (int dy = -1; dy <= 1; dy++) {
                    BlockPos p = worldPosition.offset(dx, dy, dz);
                    if (sl.getBlockState(p).getCollisionShape(sl, p).isEmpty()
                            && sl.getBlockState(p.above()).getCollisionShape(sl, p.above()).isEmpty()
                            && sl.getBlockState(p.below()).isFaceSturdy(sl, p.below(), Direction.UP)) {
                        opts.add(p);
                    }
                }
            }
        }
        return opts.isEmpty() ? null : opts.get(sl.random.nextInt(opts.size()));
    }

    @Override
    protected void saveAdditional(CompoundTag tag, HolderLookup.Provider reg) {
        super.saveAdditional(tag, reg);
        ContainerHelper.saveAllItems(tag, net.minecraft.core.NonNullList.withSize(1, container.getItem(0)), reg);
        tag.putInt("Max", max);
        tag.putInt("Cd", cooldown);
        ListTag l = new ListTag();
        for (UUID u : alive) l.add(NbtUtils.createUUID(u));
        tag.put("Alive", l);
    }

    @Override
    protected void loadAdditional(CompoundTag tag, HolderLookup.Provider reg) {
        super.loadAdditional(tag, reg);
        net.minecraft.core.NonNullList<ItemStack> items = net.minecraft.core.NonNullList.withSize(1, ItemStack.EMPTY);
        ContainerHelper.loadAllItems(tag, items, reg);
        container.setItem(0, items.get(0));
        max = tag.contains("Max") ? tag.getInt("Max") : 3;
        cooldown = tag.getInt("Cd");
        alive.clear();
        for (Tag t : tag.getList("Alive", Tag.TAG_INT_ARRAY)) alive.add(NbtUtils.loadUUID(t));
    }
}
