package com.example.gunsmod;

import java.util.List;
import net.minecraft.core.BlockPos;
import net.minecraft.core.component.DataComponents;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.TooltipFlag;
import net.minecraft.world.item.component.CustomData;
import net.minecraft.world.item.context.UseOnContext;

/**
 * WHITE stores a bot (right-click an armed bot); PURPLE respawns the stored bot;
 * GREEN / RED spawn a random-loadout bot for the green (ally) / red (enemy) team.
 */
public class CrystalItem extends Item {
    public enum Kind { WHITE, PURPLE, GREEN, RED }

    public final Kind kind;

    public CrystalItem(Item.Properties props, Kind kind) {
        super(props.stacksTo(kind == Kind.PURPLE ? 1 : 16));
        this.kind = kind;
    }

    public boolean usableInRespawner() {
        return kind != Kind.WHITE;
    }

    public static CompoundTag data(ItemStack st) {
        return st.getOrDefault(DataComponents.CUSTOM_DATA, CustomData.EMPTY).copyTag().getCompound("Bot");
    }

    /** Bot data for a spawn: stored for purple, freshly randomised for green / red. */
    public static CompoundTag spawnData(ItemStack st, ServerLevel sl) {
        if (!(st.getItem() instanceof CrystalItem c)) return new CompoundTag();
        return switch (c.kind) {
            case PURPLE -> data(st);
            case GREEN -> RandomLoadout.make(sl.random, true, sl.registryAccess());
            case RED -> RandomLoadout.make(sl.random, false, sl.registryAccess());
            default -> new CompoundTag();
        };
    }

    @Override
    public boolean isFoil(ItemStack st) {
        return kind == Kind.PURPLE;
    }

    @Override
    public InteractionResult interactLivingEntity(ItemStack st, Player player, LivingEntity target, InteractionHand hand) {
        if (kind != Kind.WHITE || !(target instanceof GunBotEntity bot)) return InteractionResult.PASS;
        if (player.level().isClientSide) return InteractionResult.SUCCESS;
        if (!bot.hasAnyGun()) {
            player.displayClientMessage(Component.literal("Give the bot a weapon first"), true);
            return InteractionResult.FAIL;
        }
        if (bot.isMachineBound()) {
            player.displayClientMessage(Component.literal("This bot is managed by a respawner or arena"), true);
            return InteractionResult.FAIL;
        }
        ItemStack out = new ItemStack(GunsMod.CRYSTAL_PURPLE.get());
        CompoundTag root = new CompoundTag();
        root.put("Bot", bot.exportData(player.registryAccess()));
        out.set(DataComponents.CUSTOM_DATA, CustomData.of(root));
        bot.discard();
        if (!player.getAbilities().instabuild) st.shrink(1);
        if (st.isEmpty()) player.setItemInHand(hand, out);
        else player.getInventory().placeItemBackInInventory(out);
        player.displayClientMessage(Component.literal("Bot stored in the crystal"), true);
        return InteractionResult.CONSUME;
    }

    @Override
    public InteractionResult useOn(UseOnContext ctx) {
        if (kind == Kind.WHITE) return InteractionResult.PASS;
        if (!(ctx.getLevel() instanceof ServerLevel sl)) return InteractionResult.SUCCESS;
        CompoundTag d = spawnData(ctx.getItemInHand(), sl);
        if (d.isEmpty()) return InteractionResult.FAIL;
        BlockPos pos = ctx.getClickedPos().relative(ctx.getClickedFace());
        GunBotEntity bot = GunsMod.GUN_BOT.get().create(sl);
        if (bot == null) return InteractionResult.FAIL;
        bot.moveTo(pos.getX() + 0.5, pos.getY(), pos.getZ() + 0.5, ctx.getRotation(), 0f);
        bot.importData(d, sl.registryAccess());
        bot.setNoLoot(true);
        Player p = ctx.getPlayer();
        if (bot.isAlly() && p != null) bot.setAlly(true, p.getUUID());
        sl.addFreshEntity(bot);
        return InteractionResult.CONSUME;
    }

    @Override
    public void appendHoverText(ItemStack st, TooltipContext ctx, List<Component> tip, TooltipFlag flag) {
        switch (kind) {
            case WHITE -> tip.add(Component.literal("Right-click an armed bot to store it").withStyle(net.minecraft.ChatFormatting.GRAY));
            case PURPLE -> {
                CompoundTag d = data(st);
                if (d.isEmpty()) return;
                tip.add(Component.literal(d.getBoolean("Ally") ? "Ally bot" : "Enemy bot").withStyle(net.minecraft.ChatFormatting.LIGHT_PURPLE));
                tip.add(Component.literal("Right-click the ground to spawn it").withStyle(net.minecraft.ChatFormatting.GRAY));
            }
            case GREEN -> tip.add(Component.literal("Random-loadout GREEN team bot (use in a Respawner)").withStyle(net.minecraft.ChatFormatting.GREEN));
            case RED -> tip.add(Component.literal("Random-loadout RED team bot (use in a Respawner)").withStyle(net.minecraft.ChatFormatting.RED));
        }
    }
}
