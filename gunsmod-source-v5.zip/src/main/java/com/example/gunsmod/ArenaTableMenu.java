package com.example.gunsmod;

import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.player.Inventory;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.inventory.AbstractContainerMenu;
import net.minecraft.world.inventory.ContainerData;
import net.minecraft.world.inventory.ContainerLevelAccess;
import net.minecraft.world.inventory.SimpleContainerData;
import net.minecraft.world.item.ItemStack;

public class ArenaTableMenu extends AbstractContainerMenu {
    public final ContainerData data;
    private final ArenaTableBlockEntity be;
    private final ContainerLevelAccess access;

    public ArenaTableMenu(int id, Inventory inv) {
        this(id, inv, null, new SimpleContainerData(8), ContainerLevelAccess.NULL);
    }

    public ArenaTableMenu(int id, Inventory inv, ArenaTableBlockEntity be, ContainerData data, ContainerLevelAccess access) {
        super(GunsMod.ARENA_MENU.get(), id);
        this.be = be;
        this.data = data;
        this.access = access;
        this.addDataSlots(data);
    }

    /** 0/1 team size -/+, 2/3 minutes -/+, 4/5 kill limit -/+, 10 watch AI vs AI, 11 play (red team), 12 stop. */
    @Override
    public boolean clickMenuButton(Player player, int id) {
        if (be == null) return false;
        switch (id) {
            case 0 -> be.adjust(0, -1);
            case 1 -> be.adjust(0, 1);
            case 2 -> be.adjust(1, -1);
            case 3 -> be.adjust(1, 1);
            case 4 -> be.adjust(2, -1);
            case 5 -> be.adjust(2, 1);
            case 10 -> { if (player instanceof ServerPlayer sp) be.start(sp, false); }
            case 11 -> { if (player instanceof ServerPlayer sp) be.start(sp, true); }
            case 12 -> be.stopByUser();
            default -> { return false; }
        }
        return true;
    }

    @Override
    public ItemStack quickMoveStack(Player player, int index) {
        return ItemStack.EMPTY;
    }

    @Override
    public boolean stillValid(Player player) {
        return stillValid(access, player, GunsMod.ARENA_TABLE.get()) || player.isSpectator();
    }
}
