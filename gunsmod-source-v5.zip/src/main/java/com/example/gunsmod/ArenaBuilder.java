package com.example.gunsmod;

import java.util.ArrayList;
import java.util.List;
import net.minecraft.core.BlockPos;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.state.BlockState;

/** Builds the 30x30 enclosed battle arena: floor, 10-high walls, cover, red/green spawn pads, lights and the match table. */
public final class ArenaBuilder {
    public static final int SIZE = 30;
    private static final int WALL_H = 10;

    private ArenaBuilder() {}

    private static void set(ServerLevel sl, int x, int y, int z, Block b) {
        sl.setBlock(new BlockPos(x, y, z), b.defaultBlockState(), 2);
    }

    /** Corner (north-west) of the arena when the player marks {@code center}. */
    public static BlockPos cornerFor(BlockPos center) {
        return center.offset(-SIZE / 2, 0, -SIZE / 2);
    }

    // west-half cover rectangles {x0, z0, x1, z1, height, blockIndex}; mirrored onto the east half
    private static final int[][] COVER = {
            {7, 4, 8, 8, 2, 0}, {7, 21, 8, 25, 2, 0},
            {11, 11, 12, 12, 2, 1}, {11, 17, 12, 18, 2, 1},
            {10, 1, 12, 2, 1, 2}, {10, 27, 12, 28, 1, 2},
            {13, 6, 14, 9, 2, 3}, {13, 20, 14, 23, 2, 3},
            {4, 8, 5, 9, 1, 2}, {4, 20, 5, 21, 1, 2},
            {13, 13, 16, 16, 1, 4}, // low centre block (spans the middle)
    };
    private static final Block[] COVER_BLOCKS = {Blocks.BRICKS, Blocks.SPRUCE_PLANKS, Blocks.SANDSTONE, Blocks.COBBLESTONE, Blocks.SMOOTH_STONE};

    public static void build(ServerLevel sl, BlockPos center) {
        BlockPos o = cornerFor(center);
        int x0 = o.getX(), y0 = o.getY(), z0 = o.getZ();
        // foundation + clear volume
        for (int lx = 0; lx < SIZE; lx++) {
            for (int lz = 0; lz < SIZE; lz++) {
                int x = x0 + lx, z = z0 + lz;
                for (int y = y0 - 4; y < y0; y++) {
                    BlockState s = sl.getBlockState(new BlockPos(x, y, z));
                    if (s.isAir() || s.canBeReplaced() || !s.getFluidState().isEmpty()) set(sl, x, y, z, Blocks.STONE);
                }
                set(sl, x, y0, z, ((lx / 5) + (lz / 5)) % 2 == 0 ? Blocks.SMOOTH_STONE : Blocks.STONE_BRICKS);
                for (int y = y0 + 1; y <= y0 + WALL_H + 2; y++) set(sl, x, y, z, Blocks.AIR);
            }
        }
        // centre line + spawn pads
        for (int lz = 0; lz < SIZE; lz++) {
            set(sl, x0 + 14, y0, z0 + lz, Blocks.WHITE_CONCRETE);
            set(sl, x0 + 15, y0, z0 + lz, Blocks.WHITE_CONCRETE);
        }
        for (int lx = 1; lx <= 5; lx++) {
            for (int lz = 11; lz <= 18; lz++) {
                set(sl, x0 + lx, y0, z0 + lz, Blocks.RED_CONCRETE);
                set(sl, x0 + (SIZE - 1 - lx), y0, z0 + lz, Blocks.LIME_CONCRETE);
            }
        }
        // walls (10 high) with sea lanterns for light
        for (int i = 0; i < SIZE; i++) {
            for (int h = 1; h <= WALL_H; h++) {
                Block wb = (h == 7 && i % 5 == 2) ? Blocks.SEA_LANTERN : (h == WALL_H ? Blocks.POLISHED_ANDESITE : Blocks.STONE_BRICKS);
                set(sl, x0 + i, y0 + h, z0, wb);
                set(sl, x0 + i, y0 + h, z0 + SIZE - 1, wb);
                set(sl, x0, y0 + h, z0 + i, wb);
                set(sl, x0 + SIZE - 1, y0 + h, z0 + i, wb);
            }
        }
        // cover
        for (int[] c : COVER) {
            Block b = COVER_BLOCKS[c[5]];
            fill(sl, x0 + c[0], y0 + 1, z0 + c[1], x0 + c[2], y0 + c[4], z0 + c[3], b);
            if (c[5] != 4) fill(sl, x0 + SIZE - 1 - c[2], y0 + 1, z0 + c[1], x0 + SIZE - 1 - c[0], y0 + c[4], z0 + c[3], b);
        }
        // spawn points
        List<BlockPos> red = new ArrayList<>(), green = new ArrayList<>();
        int[][] spots = {{3, 12}, {3, 14}, {3, 16}, {5, 13}, {5, 15}, {2, 18}};
        for (int[] s : spots) {
            red.add(new BlockPos(x0 + s[0], y0 + 1, z0 + s[1]));
            green.add(new BlockPos(x0 + SIZE - 1 - s[0], y0 + 1, z0 + s[1]));
        }
        // match table against the north wall, centred, with a lit frame
        BlockPos table = new BlockPos(x0 + 14, y0 + 1, z0 + 1);
        sl.setBlock(table, GunsMod.ARENA_TABLE.get().defaultBlockState(), 3);
        set(sl, x0 + 13, y0 + 1, z0 + 1, Blocks.SEA_LANTERN);
        set(sl, x0 + 15, y0 + 1, z0 + 1, Blocks.SEA_LANTERN);
        if (sl.getBlockEntity(table) instanceof ArenaTableBlockEntity be) be.configure(o, red, green);
    }

    private static void fill(ServerLevel sl, int xa, int ya, int za, int xb, int yb, int zb, Block b) {
        for (int x = Math.min(xa, xb); x <= Math.max(xa, xb); x++)
            for (int y = Math.min(ya, yb); y <= Math.max(ya, yb); y++)
                for (int z = Math.min(za, zb); z <= Math.max(za, zb); z++) set(sl, x, y, z, b);
    }
}
