package com.example.gunsmod;

import java.util.UUID;

/** Block entities that spawn and track bots (respawner machine, arena table). */
public interface BotHost {
    void onBotGone(UUID id);
}
