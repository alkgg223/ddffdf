package com.example.gunsmod;

import java.util.List;
import java.util.Locale;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.screens.inventory.AbstractContainerScreen;
import net.minecraft.network.chat.Component;
import net.minecraft.util.FormattedCharSequence;
import net.minecraft.world.entity.player.Inventory;
import net.minecraft.world.item.ItemStack;

public class GunCustomizerScreen extends AbstractContainerScreen<GunCustomizerMenu> {
    private static final String[] CATS = {"Optic", "Muzzle", "Underbarrel", "Ammo", "Finish"};
    private static final int CAT_X = 10;
    private static final int CAT_Y = 52;
    private static final int CAT_W = 140;
    private static final int CAT_H = 24;
    private static final int OPT_H = 23;

    private int cat = 0;
    private float yaw = 148f;
    private float pitch = 14f;
    private boolean dragged = false;

    public GunCustomizerScreen(GunCustomizerMenu menu, Inventory inv, Component title) {
        super(menu, inv, title);
        this.imageWidth = 162;
        this.imageHeight = 102;
    }

    @Override
    protected void init() {
        super.init();
        // inventory block sits bottom-centre, kept clear of the side columns
        int centre = (width - imageWidth) / 2;
        this.leftPos = Math.max(158, Math.min(centre, width - imageWidth - 158));
        this.topPos = height - imageHeight - 6;
    }

    @Override
    protected void renderLabels(GuiGraphics g, int mx, int my) {
    }

    private int optX() {
        return width - 150;
    }

    private ItemStack gun() {
        return menu.getSlot(0).getItem();
    }

    private boolean hasGun() {
        return gun().getItem() instanceof GunItem;
    }

    /** Option rows for the active category: {label, cost, info, buttonId, equipped(0/1)}. */
    private List<String[]> options() {
        ItemStack st = gun();
        List<String[]> l = new java.util.ArrayList<>();
        if (!(st.getItem() instanceof GunItem gi)) return l;
        String[] names; String[] costs; String[] infos; int base; int cur; int count;
        switch (cat) {
            case 0 -> { if (gi.type.scoped) return l; names = GunCustomizerMenu.SCOPE_NAMES; costs = GunCustomizerMenu.SCOPE_COST; infos = GunCustomizerMenu.SCOPE_INFO; base = 10; cur = GunItem.getScope(st); }
            case 1 -> { if (!GunItem.supportsMuzzle(gi.type)) return l; names = GunCustomizerMenu.MUZZLE_NAMES; costs = GunCustomizerMenu.MUZZLE_COST; infos = GunCustomizerMenu.MUZZLE_INFO; base = 20; cur = GunItem.getMuzzle(st); }
            case 2 -> { if (!GunItem.supportsUnder(gi.type)) return l; names = GunCustomizerMenu.UNDER_NAMES; costs = GunCustomizerMenu.UNDER_COST; infos = GunCustomizerMenu.UNDER_INFO; base = 30; cur = GunItem.getUnder(st); }
            default -> { names = GunCustomizerMenu.AMMO_NAMES; costs = GunCustomizerMenu.AMMO_COST; infos = GunCustomizerMenu.AMMO_INFO; base = 40; cur = GunItem.getAmmoType(st); }
        }
        count = names.length;
        if (cat != 3 && cur != 0) l.add(new String[]{"Remove", "", infos[0], String.valueOf(base), "0"});
        for (int i = (cat == 3 ? 0 : 1); i < count; i++) {
            l.add(new String[]{names[i], costs[i], infos[i], String.valueOf(base + i), cur == i ? "1" : "0"});
        }
        return l;
    }

    private int swatchX(int i) {
        return optX() + (i % 6) * 24;
    }

    private int swatchY(int i) {
        return 50 + (i / 6) * 20;
    }

    private String currentValue(int c) {
        ItemStack st = gun();
        if (!(st.getItem() instanceof GunItem gi)) return "—";
        return switch (c) {
            case 0 -> gi.type.scoped ? "Built-in scope" : GunCustomizerMenu.SCOPE_NAMES[GunItem.getScope(st)];
            case 1 -> GunItem.supportsMuzzle(gi.type) ? GunCustomizerMenu.MUZZLE_NAMES[GunItem.getMuzzle(st)] : "Not available";
            case 2 -> GunItem.supportsUnder(gi.type) ? GunCustomizerMenu.UNDER_NAMES[GunItem.getUnder(st)] : "Not available";
            case 3 -> GunCustomizerMenu.AMMO_NAMES[GunItem.getAmmoType(st)];
            default -> GunItem.getPaint(st) == 0 ? "Factory finish" : Paints.NAMES[GunItem.getPaint(st)];
        };
    }

    private void stat(GuiGraphics g, String name, String value, float frac, int x, int y, int w, boolean goodHigh) {
        GunUi.text(g, font, name, x, y, 0.8f, GunUi.DIM);
        GunUi.textRight(g, font, value, x + w, y, 0.85f, GunUi.TXT);
        g.fill(x, y + 8, x + w, y + 9, 0xFF2A303A);
        int fw = (int) (w * Math.max(0.03f, Math.min(1f, frac)));
        g.fill(x, y + 8, x + fw, y + 9, goodHigh ? 0xFFDADDE3 : 0xFFE0A030);
    }

    @Override
    protected void renderBg(GuiGraphics g, float pt, int mx, int my) {
        GunUi.background(g, width, height);
        ItemStack st = gun();
        GunItem gi = hasGun() ? (GunItem) st.getItem() : null;

        GunUi.label(g, font, "Customize", 10, 8);
        GunUi.text(g, font, gi != null ? st.getHoverName().getString() : "Gun Customizer", 10, 18, 1.8f, GunUi.TXT);
        if (gi != null) {
            GunUi.text(g, font, GunsMod.AMMO_ITEMS.get(gi.type).get().getDescription().getString(), 10, 34, 0.9f, GunUi.DIM);
        }

        // ---- category column
        for (int i = 0; i < CATS.length; i++) {
            int y = CAT_Y + i * (CAT_H + 3);
            boolean act = i == cat;
            boolean hov = mx >= CAT_X && mx < CAT_X + CAT_W && my >= y && my < y + CAT_H;
            g.fill(CAT_X, y, CAT_X + CAT_W, y + CAT_H, act || hov ? 0xC0202632 : 0x90141820);
            int sw = CAT_X + 5;
            g.fill(sw, y + 6, sw + 16, y + 22, 0xFF0C0F14);
            if (i == 4 && gi != null) {
                g.fill(sw + 2, y + 8, sw + 14, y + 20, Paints.COLORS[GunItem.getPaint(st)]);
            } else {
                g.fill(sw + 3, y + 9, sw + 13, y + 19, 0xFF3A404A);
            }
            GunUi.text(g, font, CATS[i], CAT_X + 28, y + 5, 0.85f, GunUi.DIM);
            GunUi.text(g, font, currentValue(i), CAT_X + 28, y + 15, 0.95f, GunUi.TXT);
            if (act) GunUi.brackets(g, CAT_X - 2, y - 2, CAT_X + CAT_W + 2, y + CAT_H + 2, GunUi.AMBER);
        }

        // ---- options column
        int ox = optX();
        GunUi.label(g, font, CATS[cat], ox, 36);
        String info = null;
        if (gi != null && cat == 4) {
            for (int i = 0; i < Paints.COUNT; i++) {
                int sx = swatchX(i), sy = swatchY(i);
                boolean on = GunItem.getPaint(st) == i;
                boolean hov = mx >= sx && mx < sx + 22 && my >= sy && my < sy + 16;
                g.fill(sx, sy, sx + 22, sy + 16, on ? GunUi.AMBER : (hov ? 0xFFB0B6C0 : 0xFF0C0F14));
                if (i >= 7) {
                    g.blit(net.minecraft.resources.ResourceLocation.fromNamespaceAndPath(GunsMod.MODID, "textures/item/gunskin_" + i + ".png"),
                            sx + 1, sy + 1, 20, 14, 0f, 8f, 128, 56, 128, 72);
                } else {
                    g.fill(sx + 1, sy + 1, sx + 21, sy + 15, Paints.COLORS[i]);
                }
                if (hov) info = Paints.NAMES[i] + (Paints.GLOW[i] ? " (neon glow)" : "") + " — free";
            }
            if (info == null) info = Paints.NAMES[GunItem.getPaint(st)] + " (equipped)";
        } else if (gi != null) {
            List<String[]> opts = options();
            if (opts.isEmpty()) {
                String msg = cat == 0 ? "This weapon already has a built-in scope." : cat == 1 ? "This weapon cannot take a muzzle device." : "This weapon cannot take an underbarrel attachment.";
                info = msg;
            }
            for (int i = 0; i < opts.size(); i++) {
                String[] o = opts.get(i);
                int y = 50 + i * (OPT_H + 2);
                boolean remove = o[0].equals("Remove");
                boolean eq = o[4].equals("1");
                boolean hov = mx >= ox && mx < ox + 140 && my >= y && my < y + OPT_H;
                g.fill(ox, y, ox + 140, y + OPT_H, hov ? 0xE0262C38 : 0xB0141820);
                if (eq) GunUi.brackets(g, ox - 1, y - 1, ox + 141, y + OPT_H + 1, GunUi.AMBER);
                if (remove) {
                    g.drawString(font, "Remove", ox + 8, y + 9, GunUi.RED, false);
                } else {
                    g.fill(ox + 5, y + 6, ox + 19, y + 20, 0xFF0C0F14);
                    g.fill(ox + 7, y + 11, ox + 17, y + 15, 0xFF5A616C);
                    GunUi.text(g, font, o[0], ox + 26, y + 5, 0.95f, GunUi.TXT);
                    GunUi.text(g, font, eq ? "EQUIPPED" : o[1], ox + 26, y + 15, 0.8f, eq ? GunUi.AMBER : GunUi.DIM);
                }
                if (hov) info = o[2];
                else if (eq && info == null) info = o[2];
            }
        }
        if (info != null) {
            int iy = cat == 4 ? 160 : 50 + options().size() * (OPT_H + 2) + 6;
            int n = 0;
            for (FormattedCharSequence line : font.split(Component.literal(info), 160)) {
                g.pose().pushPose();
                g.pose().translate(ox, iy + n * 9, 0);
                g.pose().scale(0.85f, 0.85f, 1f);
                g.drawString(font, line, 0, 0, 0xFFB8C0CC, false);
                g.pose().popPose();
                if (++n >= 4) break;
            }
        }

        // ---- stats (bottom-left)
        if (gi != null) {
            GunType t = gi.type;
            int mz = GunItem.mods(st);
            int sy0 = height - 84;
            float dmg = t.damage * t.pellets * GunItem.damageMult(mz);
            int rpm = (int) (1200f / t.fireDelay);
            int recoil = Math.round(t.recoil * 10f * GunItem.recoilMult(mz));
            int acc = Math.max(5, Math.min(100, Math.round(100f - t.spread * 10f * GunItem.spreadMult(mz))));
            int range = Math.round((float) t.range * GunItem.rangeMult(mz));
            int w = 128;
            stat(g, "Damage", String.format(Locale.ROOT, "%.1f", dmg), dmg / 25f, 10, sy0, w, true);
            stat(g, "Fire rate", String.valueOf(rpm), rpm / 1200f, 10, sy0 + 11, w, true);
            stat(g, "Recoil", String.valueOf(recoil), recoil / 60f, 10, sy0 + 22, w, false);
            stat(g, "Accuracy", String.valueOf(acc), acc / 100f, 10, sy0 + 33, w, true);
            stat(g, "Range", range + "m", range / 200f, 10, sy0 + 44, w, true);
            stat(g, "Reload", String.format(Locale.ROOT, "%.1fs", t.reloadTicks / 20f), 1f - t.reloadTicks / 200f, 10, sy0 + 55, w, true);
            stat(g, "Magazine", String.valueOf(t.magSize), t.magSize / 150f, 10, sy0 + 66, w, true);
        }

        GunUi.textRight(g, font, "Drag to rotate  ·  Esc to close", width - 10, height - 14, 0.8f, 0xFF5E6672);
        GunUi.label(g, font, "Weapon", leftPos + 72 + 24, topPos + 6);

        // ---- 3D preview (drawn last)
        int cx0 = CAT_X + CAT_W + 14;
        int cx1 = optX() - 14;
        int cw = cx1 - cx0;
        int ch = Math.max(60, topPos - 24);
        if (gi != null) {
            float sway = dragged ? 0f : (float) Math.sin((minecraft != null ? minecraft.player.tickCount : 0) * 0.03 + pt * 0.03) * 6f;
            float sc = Math.min(cw * 0.95f, ch * 2.4f);
            GunUi.gun(g, st, cx0 + cw / 2f, 16 + ch / 2f, sc, yaw + sway, pitch);
        } else {
            String m = "Put a weapon in the slot below";
            g.drawString(font, m, cx0 + (cw - font.width(m)) / 2, 16 + ch / 2, GunUi.DIM, false);
        }
    }

    @Override
    public void render(GuiGraphics g, int mx, int my, float pt) {
        super.render(g, mx, my, pt);
        this.renderTooltip(g, mx, my);
    }

    @Override
    public boolean mouseDragged(double mx, double my, int button, double dx, double dy) {
        int cx0 = CAT_X + CAT_W + 14;
        if (mx >= cx0 && mx < optX() - 14 && my < topPos) {
            yaw += (float) dx * 0.9f;
            pitch = Math.max(-40f, Math.min(50f, pitch + (float) dy * 0.5f));
            dragged = true;
            return true;
        }
        return super.mouseDragged(mx, my, button, dx, dy);
    }

    @Override
    public boolean mouseClicked(double mx, double my, int button) {
        for (int i = 0; i < CATS.length; i++) {
            int y = CAT_Y + i * (CAT_H + 3);
            if (mx >= CAT_X && mx < CAT_X + CAT_W && my >= y && my < y + CAT_H) {
                cat = i;
                return true;
            }
        }
        if (hasGun() && minecraft != null && minecraft.gameMode != null) {
            if (cat == 4) {
                for (int i = 0; i < Paints.COUNT; i++) {
                    if (mx >= swatchX(i) && mx < swatchX(i) + 22 && my >= swatchY(i) && my < swatchY(i) + 16) {
                        minecraft.gameMode.handleInventoryButtonClick(menu.containerId, 100 + i);
                        return true;
                    }
                }
            } else {
                List<String[]> opts = options();
                int ox = optX();
                for (int i = 0; i < opts.size(); i++) {
                    int y = 50 + i * (OPT_H + 2);
                    if (mx >= ox && mx < ox + 140 && my >= y && my < y + OPT_H) {
                        minecraft.gameMode.handleInventoryButtonClick(menu.containerId, Integer.parseInt(opts.get(i)[3]));
                        return true;
                    }
                }
            }
        }
        return super.mouseClicked(mx, my, button);
    }
}
