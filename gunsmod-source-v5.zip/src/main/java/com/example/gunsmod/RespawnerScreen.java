package com.example.gunsmod;

import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.screens.inventory.AbstractContainerScreen;
import net.minecraft.network.chat.Component;
import net.minecraft.world.entity.player.Inventory;
import net.minecraft.world.item.ItemStack;

public class RespawnerScreen extends AbstractContainerScreen<RespawnerMenu> {
    public RespawnerScreen(RespawnerMenu menu, Inventory inv, Component title) {
        super(menu, inv, title);
        this.imageWidth = 162;
        this.imageHeight = 102;
    }

    @Override
    protected void init() {
        super.init();
        this.leftPos = (width - imageWidth) / 2;
        this.topPos = height - imageHeight - 6;
    }

    @Override
    protected void renderLabels(GuiGraphics g, int mx, int my) {
    }

    private int bx(int i) {
        return width / 2 - 78 + i * 40;
    }

    private int by() {
        return 120;
    }

    @Override
    protected void renderBg(GuiGraphics g, float pt, int mx, int my) {
        GunUi.background(g, width, height);
        GunUi.label(g, font, "SPAWNER", 10, 9);
        GunUi.text(g, font, "Bot Respawner", 10, 20, 1.7f, GunUi.TXT);
        int cx = width / 2;
        GunUi.panel(g, cx - 90, 44, cx + 90, 112);
        GunUi.text(g, font, "Max bots", cx - 82, 52, 0.9f, GunUi.DIM);
        String m = String.valueOf(menu.data.get(0));
        GunUi.text(g, font, m, cx - font.width(m) * 1.6f * 0.5f + 40, 62, 1.6f, GunUi.TXT);
        GunUi.text(g, font, "Alive: " + menu.data.get(1) + " / " + menu.data.get(0), cx - 82, 86, 0.9f, GunUi.AMBER);
        ItemStack c = menu.crystal.getItem(0);
        String st = c.isEmpty() ? "Put a purple crystal in the slot below" : (menu.data.get(2) > 0 ? "Next respawn in " + menu.data.get(2) + "s" : "Active");
        GunUi.text(g, font, st, cx - 82, 99, 0.85f, c.isEmpty() ? GunUi.RED : GunUi.DIM);
        String[] lab = {"-5", "-1", "+1", "+5"};
        for (int i = 0; i < 4; i++) {
            boolean hov = mx >= bx(i) && mx < bx(i) + 36 && my >= by() && my < by() + 16;
            g.fill(bx(i), by(), bx(i) + 36, by() + 16, hov ? 0xFFF0B040 : GunUi.AMBER);
            g.drawString(font, lab[i], bx(i) + (36 - font.width(lab[i])) / 2, by() + 4, 0xFF1A1305, false);
        }
        GunUi.label(g, font, "Crystal", leftPos + 72 + 24, topPos + 6);
    }

    @Override
    public void render(GuiGraphics g, int mx, int my, float pt) {
        super.render(g, mx, my, pt);
        this.renderTooltip(g, mx, my);
    }

    @Override
    public boolean mouseClicked(double mx, double my, int button) {
        int[] ids = {2, 0, 1, 3};
        for (int i = 0; i < 4; i++) {
            if (mx >= bx(i) && mx < bx(i) + 36 && my >= by() && my < by() + 16 && minecraft != null && minecraft.gameMode != null) {
                minecraft.gameMode.handleInventoryButtonClick(menu.containerId, ids[i]);
                return true;
            }
        }
        return super.mouseClicked(mx, my, button);
    }
}
