package com.example.gunsmod;

import net.minecraft.world.Container;
import net.minecraft.world.SimpleContainer;
import net.minecraft.world.entity.player.Inventory;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.inventory.AbstractContainerMenu;
import net.minecraft.world.inventory.ContainerData;
import net.minecraft.world.inventory.ContainerLevelAccess;
import net.minecraft.world.inventory.SimpleContainerData;
import net.minecraft.world.inventory.Slot;
import net.minecraft.world.item.ItemStack;

public class RespawnerMenu extends AbstractContainerMenu {
    public final Container crystal;
    public final ContainerData data;
    private final ContainerLevelAccess access;

    public RespawnerMenu(int id, Inventory inv) {
        this(id, inv, new SimpleContainer(1), new SimpleContainerData(3), ContainerLevelAccess.NULL);
    }

    public RespawnerMenu(int id, Inventory inv, Container crystal, ContainerData data, ContainerLevelAccess access) {
        super(GunsMod.RESPAWNER_MENU.get(), id);
        this.crystal = crystal;
        this.data = data;
        this.access = access;
        this.addSlot(new Slot(crystal, 0, 72, 0) {
            @Override
            public boolean mayPlace(ItemStack st) {
                return st.getItem() instanceof CrystalItem c && c.usableInRespawner();
            }

            @Override
            public int getMaxStackSize() {
                return 1;
            }
        });
        for (int r = 0; r < 3; r++) for (int c = 0; c < 9; c++) this.addSlot(new Slot(inv, c + r * 9 + 9, c * 18, 26 + r * 18));
        for (int c = 0; c < 9; c++) this.addSlot(new Slot(inv, c, c * 18, 84));
        this.addDataSlots(data);
    }

    @Override
    public boolean clickMenuButton(Player player, int id) {
        int max = data.get(0);
        switch (id) {
            case 0 -> data.set(0, max - 1);
            case 1 -> data.set(0, max + 1);
            case 2 -> data.set(0, max - 5);
            case 3 -> data.set(0, max + 5);
            default -> { return false; }
        }
        return true;
    }

    @Override
    public ItemStack quickMoveStack(Player player, int index) {
        ItemStack ret = ItemStack.EMPTY;
        Slot slot = this.slots.get(index);
        if (slot.hasItem()) {
            ItemStack st = slot.getItem();
            ret = st.copy();
            if (index == 0) {
                if (!this.moveItemStackTo(st, 1, 37, true)) return ItemStack.EMPTY;
            } else if (!this.moveItemStackTo(st, 0, 1, false)) {
                return ItemStack.EMPTY;
            }
            if (st.isEmpty()) slot.setByPlayer(ItemStack.EMPTY); else slot.setChanged();
        }
        return ret;
    }

    @Override
    public boolean stillValid(Player player) {
        return stillValid(access, player, GunsMod.RESPAWNER.get());
    }
}
