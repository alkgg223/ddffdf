package com.example.gunsmod;

import net.minecraft.core.BlockPos;
import net.minecraft.core.component.DataComponents;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.component.CustomData;
import net.minecraft.world.item.context.UseOnContext;
import net.minecraft.world.level.Level;

/** Right-click the ground: white outline of a 30x30 arena. Right-click again: builds it. Sneak + click cancels. */
public class ArenaWandItem extends Item {
    public ArenaWandItem(Item.Properties props) {
        super(props.stacksTo(1));
    }

    private static CompoundTag tag(ItemStack st) {
        return st.getOrDefault(DataComponents.CUSTOM_DATA, CustomData.EMPTY).copyTag();
    }

    @Override
    public InteractionResult useOn(UseOnContext ctx) {
        Level level = ctx.getLevel();
        if (level.isClientSide) return InteractionResult.SUCCESS;
        ItemStack st = ctx.getItemInHand();
        Player p = ctx.getPlayer();
        CompoundTag t = tag(st);
        if (p != null && p.isShiftKeyDown()) {
            t.remove("Pend");
            st.set(DataComponents.CUSTOM_DATA, CustomData.of(t));
            p.displayClientMessage(Component.literal("Arena marker cleared"), true);
            return InteractionResult.CONSUME;
        }
        if (!t.contains("Pend")) {
            t.putLong("Pend", ctx.getClickedPos().asLong());
            st.set(DataComponents.CUSTOM_DATA, CustomData.of(t));
            if (p != null) p.displayClientMessage(Component.literal("Area marked (30x30). Right-click again to build it. Sneak+click cancels."), true);
        } else if (level instanceof ServerLevel sl) {
            BlockPos pos = BlockPos.of(t.getLong("Pend"));
            ArenaBuilder.build(sl, pos);
            t.remove("Pend");
            st.set(DataComponents.CUSTOM_DATA, CustomData.of(t));
            if (p != null) p.displayClientMessage(Component.literal("Battle arena built. Use the Match Table at the north wall."), true);
        }
        return InteractionResult.CONSUME;
    }

    @Override
    public void inventoryTick(ItemStack st, Level level, Entity entity, int slot, boolean selected) {
        if (level.isClientSide || !selected || !(entity instanceof ServerPlayer sp) || level.getGameTime() % 10 != 0) return;
        CompoundTag t = tag(st);
        if (!t.contains("Pend") || !(level instanceof ServerLevel sl)) return;
        BlockPos o = ArenaBuilder.cornerFor(BlockPos.of(t.getLong("Pend")));
        double y = o.getY() + 1.15;
        int s = ArenaBuilder.SIZE;
        for (int i = 0; i <= s; i += 2) {
            sl.sendParticles(sp, ParticleTypes.END_ROD, true, o.getX() + i, y, o.getZ(), 1, 0, 0, 0, 0);
            sl.sendParticles(sp, ParticleTypes.END_ROD, true, o.getX() + i, y, o.getZ() + s, 1, 0, 0, 0, 0);
            sl.sendParticles(sp, ParticleTypes.END_ROD, true, o.getX(), y, o.getZ() + i, 1, 0, 0, 0, 0);
            sl.sendParticles(sp, ParticleTypes.END_ROD, true, o.getX() + s, y, o.getZ() + i, 1, 0, 0, 0, 0);
        }
        for (int h = 0; h <= 10; h += 2) {
            for (int[] c : new int[][]{{0, 0}, {s, 0}, {0, s}, {s, s}}) {
                sl.sendParticles(sp, ParticleTypes.END_ROD, true, o.getX() + c[0], y + h, o.getZ() + c[1], 1, 0, 0, 0, 0);
            }
        }
    }
}
